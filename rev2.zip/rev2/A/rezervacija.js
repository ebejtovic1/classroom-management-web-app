// Radi sa fiksnim vrijednostima kada se pošalju metodama.

// Dodati event listener-e

let Kalendar = (function() {
	let periodicna = [];
	let vanredna = [];

	function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj) {
		if (periodicna.length > 0 && vanredna.length > 0) {
			//ucitani podaci
			let trazeniSemestar = null;
			if ((mjesec >= 9 && mjesec <= 11) || mjesec == 0) {
				trazeniSemestar = 'zimski';
			} else if (mjesec >= 1 && mjesec <= 5) {
				trazeniSemestar = 'ljetni';
			}
			
			for (let i = 0; i < periodicna.length; i++) {
				if (
					periodicna[i].semestar === trazeniSemestar &&
					periodicna[i].naziv === sala &&
					periodicna[i].pocetak === pocetak &&
					periodicna[i].kraj === kraj 
				) {
					let trenutniDan = moment(new Date(2019, mjesec, 1));
					let dan = moment(new Date(2019, mjesec, 1));
					while (dan.month() == mjesec) {
						//oslobodi sve dane u mjesecu
						let indeksDana = dan.date() - 1;
						kalendarRef.children[indeksDana].children[1].classList.remove('zauzeta');
						dan.add(1, 'day');
					}
					while (trenutniDan.day() !== periodicna[i].dan) {
						trenutniDan.add(1, 'day');
					}

					while (trenutniDan.month() == mjesec) {
						let indeksDana = trenutniDan.date() - 1;
						kalendarRef.children[indeksDana].children[1].classList.add('zauzeta');
						trenutniDan.add(7, 'day');
					}
				}
			}

			for (let i = 0; i < vanredna.length; i++) {
				let vanredniDatum = moment(vanredna[i].datum, 'DD.MM.YYYY');
				if (
					vanredniDatum.month() == mjesec &&
					vanredna[i].naziv === sala &&
					vanredna[i].pocetak === pocetak &&
					vanredna[i].kraj === kraj
				) {
					let indeksDana = vanredniDatum.date() - 1;
					kalendarRef.children[indeksDana].children[1].classList.add('zauzeta');
				}
			}
		}
	}

	function ucitajPodatke(periodicniPodaci, vanredniPodaci) {
		periodicna = [];
		vanredna = [];
		for (var i = 0; i < periodicniPodaci.length; i++) {
			periodicna.push(periodicniPodaci[i]);
		}
		for (var i = 0; i < vanredniPodaci.length; i++) {
			vanredna.push(vanredniPodaci[i]);
		}
	}

	function kreirajDan(dan) {
		var time = document.createElement('time');
		time.setAttribute('datetime', dan.format('YYYY-MM-DD'));
		time.innerHTML = dan.get('date');
		var span = document.createElement('span');
		span.classList.add('slobodna');

		var button = document.createElement('button');
		button.classList.add('sedmica');
		button.id = dan.get('date');
		button.appendChild(time);
		button.appendChild(span);

		return button;
	}
	function iscrtajKalendar(kalendarRef, mjesec) {
		kalendarRef.innerHTML = '';
		let godina = 2019;
		var prvi = new Date(godina, mjesec, 1);
		var danUSedmici = prvi.getDay();
		if (danUSedmici == 0) danUSedmici = 7; //korekcija za nedjelju
		var trenutni_dan = moment(prvi);

		let brojDanaUmjesecu = trenutni_dan.daysInMonth();

		for (let i = 1; i <= brojDanaUmjesecu; i++) {
			var dan = kreirajDan(trenutni_dan);
			if (i == 1) {
				dan.style.gridColumn = danUSedmici;
			}
			kalendarRef.appendChild(dan);
			trenutni_dan.add(1, 'day');
		}
	}

	return {
		oboji: obojiZauzeca,
		ucitaj: ucitajPodatke,
		iscrtaj: iscrtajKalendar
	};
})();

let periodicniPodaci = [
	{
		dan: 2,
		semestar: 'ljetni',
		pocetak: '10:30',
		kraj: '12:00',
		naziv: '0-01',
		predavac: 'Vensada Okanovic'
	},
	{
		dan: 5,
		semestar: 'zimski',
		pocetak: '12:30',
		kraj: '14:00',
		naziv: 'EE1',
		predavac: 'Vedran Ljubovic'
	},
	{
		dan: 1,
		semestar: 'zimski',
		pocetak: '09:00',
		kraj: '12:00',
		naziv: 'VA1',
		predavac: 'Zeljko Juric'
	}
];
let vanredniPodaci = [
	{
		datum: '07.11.2019',
		pocetak: '12:30',
		kraj: '14:00',
		naziv: 'EE1',
		predavac: 'Haris Supic'
	},
	{
		datum: '11.11.2019',
		pocetak: '12:30',
		kraj: '14:30',
		naziv: 'EE1',
		predavac: 'Samir Ribic'
	}
];

function kreirajDan(dan) {
	var time = document.createElement('time');
	time.setAttribute('datetime', dan.format('YYYY-MM-DD'));
	time.innerHTML = dan.get('date');
	var span = document.createElement('span');
	span.classList.add('slobodna');

	var button = document.createElement('button');
	button.classList.add('sedmica');
	button.id = dan.get('date');
	button.appendChild(time);
	button.appendChild(span);

	return button;
}

function generisiKalendar(godina, mjesec) {
	var dateGrid = document.getElementById('kalendar');
	dateGrid.innerHTML = '';

	var prvi = new Date(godina, mjesec, 1);
	var danUSedmici = prvi.getDay();
	if (danUSedmici == 0) danUSedmici = 7; //korekcija za nedjelju
	var trenutni_dan = moment(prvi);

	let brojDanaUmjesecu = trenutni_dan.daysInMonth();

	for (let i = 1; i <= brojDanaUmjesecu; i++) {
		var dan = kreirajDan(trenutni_dan);
		if (i == 1) {
			dan.style.gridColumn = danUSedmici;
		}
		dateGrid.appendChild(dan);
		trenutni_dan.add(1, 'day');
	}
}

function ubaciImeMjeseca(imeMjeseca, godina) {
	var divImeMjeseca = document.getElementById('imeMjeseca');
	divImeMjeseca.innerHTML = '';
	var span = document.createElement('span');
	span.innerHTML = imeMjeseca + ' ' + godina;
	divImeMjeseca.appendChild(span);
}
const monthNames = [
	'Januar',
	'Februar',
	'Mart',
	'April',
	'Maj',
	'Juni',
	'Juli',
	'August',
	'Septembar',
	'Oktobar',
	'Novembar',
	'Decembar'
];

var trenutniDatum = new Date();
var trenutniMjesec = trenutniDatum.getMonth();
var trenutnaGodina = trenutniDatum.getFullYear();
var kalendarRef = document.getElementById('kalendar');


function prethodniMjesec() {
	trenutniMjesec--;
	if (trenutniMjesec === -1) {
		trenutniMjesec = 11;
		trenutnaGodina--;
	}
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
	Kalendar.ucitaj(periodicniPodaci, vanredniPodaci);
	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	Kalendar.oboji(document.getElementById('kalendar'), trenutniMjesec, 'EE1', '12:30', '14:00');
}

function sljedeciMjesec() {
	trenutniMjesec++;
	if (trenutniMjesec === 12) {
		trenutniMjesec = 0;
		trenutnaGodina++;
	}
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
	Kalendar.ucitaj(periodicniPodaci, vanredniPodaci);
	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	Kalendar.oboji(document.getElementById('kalendar'), trenutniMjesec, 'EE1', '12:30', '14:00');
}

window.addEventListener('DOMContentLoaded', (event) => {
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
	Kalendar.ucitaj(periodicniPodaci, vanredniPodaci);
	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	Kalendar.oboji(kalendarRef, trenutniMjesec, 'EE1', '12:30', '14:00');
});
