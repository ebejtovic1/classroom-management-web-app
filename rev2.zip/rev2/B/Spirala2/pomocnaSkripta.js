//AKO SE BILO KAKVA PROMJENA JAVI U FORMI SA INPUT-IMA
function akoSeDesiPromjenaUFormElementuNekom() {
    Kalendar.obojiZauzeca(document.getElementsByClassName("Kalendar"), datum.getMonth(), document.getElementById("selectSale").options[document.getElementById("selectSale").selectedIndex].value, document.getElementById("poc").value, document.getElementById("kra").value);
}

//ZA DUGME PRETHODNI
function pozivZaPrethodni() {
    Kalendar.iscrtajKalendar(document.getElementsByClassName("Kalendar"), datum.getMonth()-1);
}

//ZA DUGME SLJEDECI
function pozivZaSljedeci() {
    Kalendar.iscrtajKalendar(document.getElementsByClassName("Kalendar"), datum.getMonth()+1);
}

//PRILIKOM UCITAVANJA DOKUMENTA
window.addEventListener('load', function() {
    
    Kalendar.iscrtajKalendar(document.getElementsByClassName("Kalendar"), datum.getMonth());
    //Hardkodirani podatci za periodicna zauzeca
    var van1 = {datum: "06.10.2019", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"}
    var van2 = {datum: "23.11.2019", pocetak: "10:35", kraj: "11:15", naziv: "0-02", predavac: "prof. Miroslav"};
    var van3 = {datum: "19.12.2019", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"};
    var van4 = {datum: "20.10.2019", pocetak: "10:35", kraj: "11:15", naziv: "0-03", predavac: "prof. Miroslav"};
    var van5 = {datum: "21.10.2019", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"};
    
    var per1 = {dan: 0, semestar: "zimski", pocetak: "10:35", kraj: "11:15", naziv: "0-02", predavac: "prof. Miroslav"};
    var per2 = {dan: 1, semestar: "zimski", pocetak: "10:35", kraj: "11:15", naziv: "0-02", predavac: "prof. Miroslav"};
    var per4 = {dan: 3, semestar: "zimski", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"};
    var per5 = {dan: 4, semestar: "zimski", pocetak: "10:35", kraj: "11:15", naziv: "0-03", predavac: "prof. Miroslav"};
    var per7 = {dan: 6, semestar: "zimski", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"};
    var per8 = {dan: 6, semestar: "ljetni", pocetak: "10:35", kraj: "11:15", naziv: "0-01", predavac: "prof. Miroslav"};

    //Pretvaranje ovoga u jedan niz 
    var nizPerZauz = [per1, per2, per4, per5];
    var nizVanZauz = [van1, van2, van3, van4, van5];
    //Poziv ucitajPodatke funcije(Hardkodirano)
    Kalendar.ucitajPodatke(nizPerZauz, nizVanZauz);
})