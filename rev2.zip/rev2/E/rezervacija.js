window.addEventListener("resize", setDayOrientation);

pocetak.addEventListener("input", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});

kraj.addEventListener("input", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});

sala.addEventListener("change", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});
function setDayOrientation(){
    var dan = document.getElementsByClassName("dan")[0];
    if(dan == null) return;
    var screenSize = window.matchMedia("(max-width: 600px)")
    if(screenSize.matches){
        if(dan.style.gridRow == "auto / auto"){
            dan.style.gridRow = dan.style.gridColumn;
            dan.style.gridColumn = "auto";
        }
    }
    else{
        if(dan.style.gridColumn == "auto / auto"){
            dan.style.gridColumn = dan.style.gridRow;
            dan.style.gridRow = "auto";
        }
    }
}