let mjesec = 10;
function prethodniMjesec(){
    if (mjesec > 0) {
        mjesec = mjesec - 1;
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);
    }
}
function sljedeciMjesec(){
    if (mjesec < 11)
    {
        mjesec =  mjesec + 1;
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);
    }
      
}