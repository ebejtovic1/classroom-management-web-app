let assert = chai.assert;

//chai.use(require('chai-dom'));
//let jsdom = require("jsdom");
//const { JSDOM } = jsdom;
//const JSDOM = jsdom.JSDOM;
//let Kalendar = require("../Kalendar");
describe('Kalendar', function () {
    describe('ucitajPodatke()', () => {

        
    });

    describe('obojiZauzeca()', function () {
        it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', () => {


        });
        it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', () => {

        });
        it(`Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano
        je da se ne oboji zauzeće`, () => {

        });
        it(`Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano
        je da se ne oboji zauzeće`, () => {

        });
        it(`Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi
        dani oboje`, () => {

        });
        it(`Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista`, () => {

        });
        it(`Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se
        zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci`, () => {

        });


    });

    describe('iscrtajKalendar()', function () {
        //koristeni dijelovi koda iz funkcije iscrtaj koji su korišteni za implementaciju funkcije iscrtajKalendar
        //jer je lakše tako nego koristiti jquery za prolazak kroz tabelu i brojati nevidljive dane i tako to.
        before(function () {
            return JSDOM.fromFile('../html/rezervacija.html')
                .then((dom) => {
                    global.window = dom.window;
                    global.document = window.document;
                });
        })
        it("Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 4;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec-1);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1]
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td')
            //assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            //assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            //assert.equal(nevidljive.length, 5, "Nevidljivih treba biti 5");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let lastDayOfMonth = new Date(datum.getFullYear(), datum.getMonth() + 1, 0);
            const brojDana = lastDayOfMonth.getDate();//hardkodirani broj dana
            assert.equal(brojDana, 30, "Broj dana treba biti 30");

        });
        it("Pozivanje iscrtajKalendar za mjesec sa 31 dana: očekivano je da se prikaže 31 dana", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 4-1;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec-1);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1]
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td')
            assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            assert.equal(nevidljive.length, 5, "Nevidljivi treba biti 5");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let lastDayOfMonth = new Date(datum.getFullYear(), datum.getMonth() + 1, 0);
            const brojDana = lastDayOfMonth.getDate();//hardkodirani broj dana
            assert.equal(brojDana, 31, "Broj dana treba biti 31");


        });
        it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 11;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec - 1);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1]
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td')
            assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            assert.equal(nevidljive.length, 5, "Nevidljivi treba biti 5");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let dan = datum.getDay()
            assert.equal(dan, 5, "očekivano je da je 1. dan u petak");


        });
        it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 11;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1]
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td')
            //assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            //assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            //assert.equal(nevidljive.length, 5, "Nevidljivi treba biti 5");
            const datum = new Date(`${mjesec}.30.2019`);
            //let today = new Date();
            let dan = datum.getDay()
            assert.equal(dan, 6, "očekivano je da je 30. dan u subotu");

        });
        it("Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 1;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1];
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td');
            //assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            //assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let dan = datum.getDay();
            assert.equal(dan, 2, "očekivano je da je 31. dan u subotu");

        });
        it("Pozivanje iscrtajKalendar za februar: očekivano je da brojevi dana idu od 1 do 28", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 1;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1];
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td');
            assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let dan = datum.getDay();
            assert.equal(dan, 1, "očekivano je da je 28. dana");

        });
        it("Pozivanje iscrtajKalendar za august: očekivano je da brojevi dana idu od 1 do 31", function () {
            let kalendarRef = document.createElement("div");
            let mjesec = 7;

            Kalendar.iscrtajKalendar(kalendarRef, mjesec);
            let tabele = document.getElementsByTagName("table");
            let tabela = tabele[tabele.length - 1];
            let redovi = tabela.getElementsByTagName("tr");
            let kolone = redovi[1].getElementsByTagName('td');
            //assert.equal(redovi.length, 6, "Broj redova treba biti 6");
            //assert.equal(kolone.length, 7, "Broj redova treba biti 7");
            let nevidljive = document.querySelectorAll("td.nevidljiveCelije");
            const datum = new Date(`${mjesec}.1.2019`);
            //let today = new Date();
            let dan = datum.getDay();
            assert.equal(dan, 2, "očekivano je da je 31. dan u subotu");

        });


    });
});

