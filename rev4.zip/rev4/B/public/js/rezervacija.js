window.onload = () => {
    ucitajOsobe();
    ucitajSale();
}

function ucitajRezervacije() {
    let salaId = document.getElementById("odabranaSala").value;
    let osobaId = document.getElementById("osoblje").value;
    let pocetak = document.getElementById("pocetak").value;
    let kraj = document.getElementById("kraj").value;
    console.log("ucitajRezervaciju(" + pocetak + ", " + kraj + ", " + osobaId + ", " + salaId + ")")
    Pozivi.ucitajRezervacije(pocetak, kraj, osobaId, salaId);
}
function rezervacijaTermina(ref) {
    let odg = confirm("Da li želite rezervisati ovaj termin?");
    if (odg) {
        let sala = document.getElementById("odabranaSala").value;
        let pocetak = document.getElementById("pocetak").value;
        let kraj = document.getElementById("kraj").value;
        let predavac = document.getElementById("osoblje").value;
        let periodicna = document.getElementById("period").checked;
        let mjesec = Mjesec.mjesecBroj(document.getElementById("mjesec").innerHTML.toLowerCase());
        if (mjesec > 5 && mjesec < 9) {
            alert("Raspuust, pustite djecu na miru")
            return;
        }
        let datum = ref.getElementsByClassName("datum")[0].innerHTML;
        let d = new Date(2020, mjesec, datum);
        if (pocetak == "" || kraj == "") {
            alert("Unesite vrijednosti za pocetak i kraj");
            return;
        } else {
            Pozivi.rezervisiTermin(sala, d, periodicna, pocetak, kraj, predavac);
        }
    }
}

function ucitajOsobe() {
    Pozivi.ucitajOsobe().then(osobe => {
        console.log(osobe);
        osoblje = document.getElementById("osoblje");
        osobe.forEach(element => {
            noviClan = document.createElement("option");
            noviClan.id = "osoba" + element.id;
            noviClan.text = element.ime + ' ' + element.prezime
            noviClan.value = element.id;
            osoblje.add(noviClan);
        })
    })
}
function ucitajSale() {
    Pozivi.ucitajSale().then(res => {
        sale = document.getElementById("odabranaSala");
        res.forEach(element => {
            noviClan = document.createElement("option");
            noviClan.id = "sala" + element.id;
            noviClan.text = element.naziv
            noviClan.value = element.id;
            sale.add(noviClan);
        })
    })
}