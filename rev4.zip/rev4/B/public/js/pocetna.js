
var i = 0;
//funkcija koja odlucuje da li ucitati slike iz local storage ili pokupiti sa servera
async function ucitajSlike(indeks) {
    i = indeks;
    let prva = document.getElementById("prva");
    let druga = document.getElementById("druga");
    let treca = document.getElementById("treca");
    if (window.localStorage.getItem(i)) {
        //slike su vec prije ucitane, samo ih treba prikazati
        prva.src = window.localStorage.getItem(i);
        druga.src = window.localStorage.getItem(i + 1);
        treca.src = window.localStorage.getItem(i + 2);
    } else {
        Pozivi.ucitajTriSlike(i);
    }


}

function dugmePrethodni() {
    //smanjimo i za 3 zatim pozovemo ucitajSlike(i)
    document.getElementById("sljedeci").disabled = false;
    if (i >= 3) {
        i -= 3;
    } else {
        i = 0;
        document.getElementById("prethodni").disabled = true;
    }
    ucitajSlike(i);
}

function dugmeSljedeci() {
    //prvo odredimo indeks najvece slike
    document.getElementById("prethodni").disabled = false;
    let max = localStorage.getItem("brojSlika");
    if (i < max - 3) {
        i += 3;
    } else {
        i = max;
        document.getElementById("sljedeci").disabled = true;
    }
    ucitajSlike(i);
}
function statistika() {
    Pozivi.statistika();
}

window.onload = function () {
    ucitajSlike(i);
    statistika();
}
if (i == 0) {
    document.getElementById("prethodni").disabled = true;
}

