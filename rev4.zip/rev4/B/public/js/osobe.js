window.onload = dodajOsobe();

function dodajOsobe() {
    container = document.getElementsByClassName("container")[0];
    //praznimo container
    //umjesto da samo svakih 30 sekundi provjerimo prmjenu lokacije osoblja
    //ovako uzimamo u obzir ukoliko se doda i novi clan osoblja
    while (container.firstChild) {
        container.removeChild(container.firstChild);
    }
    //dohvatamo osobe
    Pozivi.ucitajOsobe().then(resultSet => {
        Pozivi.ucitajOsobeSale().then(osobe => {
            resultSet.forEach(element => {
                console.log(element);
                labelContainer = document.createElement("div");
                labelContainer.className = "label-container";
                label1 = document.createElement("label");
                label1.className = "osoba";
                label2 = document.createElement("label");
                label2.id = `osoba${element.id}`;
                label2.className = "stanje";
                label1.innerHTML = `${element.ime} ${element.prezime}`;
                label2.innerHTML = "u kancelariji";
                labelContainer.appendChild(label1);
                labelContainer.appendChild(label2);
                container.appendChild(labelContainer);
            });
            osobe.forEach(osoba => {
                label2 = document.getElementById(`osoba${osoba.Osoblje.id}`)
                label2.innerHTML = osoba.Sala.naziv;
            });
        });
    })
    setTimeout(dodajOsobe, 30000);
}