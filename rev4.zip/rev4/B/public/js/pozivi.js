const Pozivi = (function () {
    function ucitajRezervacije(pocetak, kraj, osobaId, salaId) {
        var ajax = new XMLHttpRequest();
        url = `http://localhost:8080/ucitajRezervacije/?pocetak=${pocetak}&kraj=${kraj}&osobaId=${osobaId}&salaId=${salaId}`;

        ajax.open("GET", url, true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        ajax.onreadystatechange = function () {// Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
                odg = JSON.parse(ajax.response);
                console.log(odg);
                Kalendar.ucitajPodatke(odg.periodicna, odg.vanredna);
                Kalendar.obojiZauzeca(
                    "vanjska",
                    Mjesec.trenutniMjesec(),
                    document.getElementById("odabranaSala").innerHTML,
                    document.getElementById("pocetak").value,
                    document.getElementById("kraj").value);
                crtaj();
            }
        }
    }
    function rezervisiTermin(sala, d, periodicna, pocetak, kraj, predavac) {
        let semestar, obj;
        if (d.getMonth() >= 9 || d.getMonth() == 0) {
            semestar = "zimski";
        } else if (d.getMonth() >= 2 && d.getMonth() <= 5) {
            semestar = "ljetni";
        }
        if (periodicna) {
            obj = {
                dan: (d.getDay() == 0) ? 6 : d.getDay() - 1, //ako je nedjelja postavi na 6, inace smanji za 1
                semestar: semestar,
                pocetak: pocetak,
                kraj: kraj,
                sala: sala,
                predavac: predavac
            }
        } else {
            obj = {
                datum: "" + d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(),
                pocetak: pocetak,
                kraj: kraj,
                sala: sala,
                predavac: predavac
            }
        }
        var ajax = new XMLHttpRequest();
        ajax.open("POST", "http://localhost:8080/rezervacija", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send(JSON.stringify(obj));
        ajax.onreadystatechange = function () {// Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
                try {
                    odg = JSON.parse(ajax.response);
                    console.log(odg);
                } catch{
                    alert(ajax.response);
                }
                ucitajRezervacije(pocetak, kraj, predavac, sala);
            }
        }
    }
    function ucitajTriSlike(indeksPrveSlike) {
        let prva = document.getElementById("prva");
        let druga = document.getElementById("druga");
        let treca = document.getElementById("treca");
        let ajax = new XMLHttpRequest();
        url = "http://localhost:8080/ucitajTriSlike?indeks=" + indeksPrveSlike;
        ajax.open("GET", url, true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4 && ajax.status == 200) {
                odg = JSON.parse(ajax.response);
                let l = Object.keys(odg);
                l.forEach(element => {
                    if (element) {
                        window.localStorage.setItem(element, odg[element]);
                    }
                });
                prva.src = window.localStorage.getItem(i) ? window.localStorage.getItem(i) : " ";
                druga.src = window.localStorage.getItem(i + 1) ? window.localStorage.getItem(i + 1) : " ";
                treca.src = window.localStorage.getItem(i + 2) ? window.localStorage.getItem(i + 2) : " ";
            }
        }
    }
    function statistika() {
        let odg = 0;
        let ajax = new XMLHttpRequest();
        ajax.open("GET", "http://localhost:8080/agent", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4 && ajax.status == 200) {
                res = JSON.parse(ajax.response);
                document.getElementById("chrome").innerHTML += res.agent.chrome;
                document.getElementById("mozilla").innerHTML += res.agent.mozilla;
                document.getElementById("posjetioci").innerHTML += res.ip;
            }
        }
    }
    function ucitajSale() {
        return new Promise((resolve, reject) => {
            let ajax = new XMLHttpRequest();
            ajax.open("GET", "http://localhost:8080/ucitajSale", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
            ajax.onreadystatechange = () => {
                if (ajax.readyState == 4 && ajax.status == 200) {
                    res = JSON.parse(ajax.response);
                    resolve(res);
                }
            }
        });

    }
    function ucitajOsobe() {
        return new Promise((resolve, reject) => {
            let ajax = new XMLHttpRequest();
            ajax.open("GET", "http://localhost:8080/osoblje", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
            ajax.onreadystatechange = () => {
                if (ajax.readyState == 4 && ajax.status == 200) {
                    res = JSON.parse(ajax.response);
                    resolve(res);
                }
            }
        });
    }
    function ucitajOsobeSale() {
        return new Promise((resolve, reject) => {
            let ajax = new XMLHttpRequest();
            ajax.open("GET", "http://localhost:8080/osobeSale", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
            ajax.onreadystatechange = () => {
                if (ajax.readyState == 4 && ajax.status == 200) {
                    res = JSON.parse(ajax.response);
                    resolve(res);
                }
            }
        });
    }
    return {
        ucitajRezervacije: ucitajRezervacije,
        rezervisiTermin: rezervisiTermin,
        ucitajTriSlike: ucitajTriSlike,
        statistika: statistika,
        ucitajSale: ucitajSale,
        ucitajOsobe: ucitajOsobe,
        ucitajOsobeSale: ucitajOsobeSale,
    }
}());