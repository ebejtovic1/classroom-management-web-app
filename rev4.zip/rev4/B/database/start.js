const db = require('../database/baza.js');
db.sequelize.sync({ force: true }).then(() => {
    inicijaliziraj().then(() => {
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});
function inicijaliziraj() {
    //neko nekic  - osoblje
    let prof1 = { ime: 'Neko', prezime: 'Nekic', uloga: 'profesor' };
    let prof2 = { ime: 'Drugi', prezime: 'Neko', uloga: 'asistent' };
    let prof3 = { ime: 'Test', prezime: 'Test', uloga: 'asistent' };
    let profesori = [];
    let sale = [];
    let termini = [];
    let rezervacije = [];
    return new Promise((resolve, reject) => {
        //ubacujemo profesore u bazu
        profesori.push(db.osoblje.create({ ime: prof1.ime, prezime: prof1.prezime, uloga: prof1.uloga }));
        profesori.push(db.osoblje.create({ ime: prof2.ime, prezime: prof2.prezime, uloga: prof2.uloga }));
        profesori.push(db.osoblje.create({ ime: prof3.ime, prezime: prof3.prezime, uloga: prof3.uloga }));
        //dobavljamo profesore iz baze, s tim da sada neko i drugi imaju tip reda u  tabeli osoblje
        //Promise.all saceka da se izvrse svi zahtjevi prema bazi, pa onda pozove funkciju unutar
        Promise.all(profesori).then((profesori) => {
            let neko = profesori.filter((a) => { return a.ime === 'Neko' })[0]; //jer filter vraca niz, a nama treba prvi el. niza
            let drugi = profesori.filter((a) => { return a.ime === 'Drugi' })[0];
            let test = profesori.filter((a) => { return a.ime === 'Test' })[0];

            sale.push(db.sala.create({ naziv: '1-11' }).then(sala => {
                sala.setZaduzena(neko);
                return new Promise((resolve, reject) => { resolve(sala); });
            }));
            sale.push(db.sala.create({ naziv: '1-15', osoba: drugi.id }).then(sala => {
                sala.setZaduzena(drugi);
                return new Promise((resolve, reject) => { resolve(sala); });
            }));
            Promise.all(sale).then((sale) => {
                let sala1 = sale.filter((s) => { return s.id == 1 })[0];


                termini.push(db.termin.create({ redovni: false, dan: null, datum: '2020-1-1', semestar: null, pocetak: '12:00', kraj: '13:00' }));
                termini.push(db.termin.create({ redovni: true, dan: 0, datum: null, semestar: 'zimski', pocetak: '13:00', kraj: '14:00' }));
                //Promise saceka da se svi termini unesu u bazu, zatim izvrsi ()=>{} funkciju
                Promise.all(termini).then((termini) => {

                    termin1 = termini.filter((t) => { return t.id == 1 })[0];
                    termin2 = termini.filter((t) => { return t.id == 2 })[0];

                    rezervacije.push(db.rezervacija.create({ termin: termin1.id, sala: sala1.id, osoba: neko.id }));
                    rezervacije.push(db.rezervacija.create({ termin: termin2.id, sala: sala1.id, osoba: test.id }));
                }).catch((error) => { console.log("termini greska" + error) });
            }).catch((error) => { console.log("sale greska" + error) });;
        }).catch((error) => { console.log("profesori greska" + error) });;
    }).catch((error) => { console.log("sve greska" + error) });;
}