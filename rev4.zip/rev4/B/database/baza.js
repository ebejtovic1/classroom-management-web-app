const Sequelize = require("../app/node_modules/sequelize");
const sequelize = new Sequelize("dbwt19", "root", "root", {
    host: "localhost",
    dialect: "mysql",
    logging: false,
});
const db = {};

//import modela

db.rezervacija = sequelize.import(__dirname + '/rezervacija.js');
db.termin = sequelize.import(__dirname + '/termin.js');
db.osoblje = sequelize.import(__dirname + '/osoblje.js');
db.sala = sequelize.import(__dirname + '/sala.js');


//relacije
db.osoblje.hasMany(db.rezervacija, {
    foreignKey: 'osoba'
});
db.rezervacija.belongsTo(db.osoblje, {
    foreignKey: 'osoba'
});

db.sala.hasMany(db.rezervacija, {
    foreignKey: 'sala'
});
db.rezervacija.belongsTo(db.sala, {
    foreignKey: 'sala'
});

db.termin.hasOne(db.rezervacija, {
    foreignKey: 'termin'
});
db.rezervacija.belongsTo(db.termin, {
    foreignKey: 'termin'
});

db.osoblje.hasOne(db.sala, {
    foreignKey: 'zaduzenaOsoba',
    as:'zaduzena'
});
db.sala.belongsTo(db.osoblje, {
    foreignKey: 'zaduzenaOsoba',
    as:'zaduzena'
});


db.Sequelize = Sequelize;
db.sequelize = sequelize;
module.exports = db;

