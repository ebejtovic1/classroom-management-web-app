const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const useragent = require('express-useragent');
const path = require("path")
const db = require('../database/baza.js');
const Op = db.Sequelize.Op;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.resolve(__dirname + '/../public')));
app.use(useragent.express());

//


app.get(['/', '/index', '/pocetna'], function (req, res) {
    res.sendFile(path.resolve(__dirname + '/../public/views/pocetna.html'));
});

app.get('/sale', function (req, res) {
    res.sendFile(path.resolve(__dirname + '/../public/views/sale.html'));
});

app.get('/rezervacija', function (req, res) {
    res.sendFile(path.resolve(__dirname + '/../public/views/rezervacija.html'));
});

app.get('/unos', function (req, res) {
    res.sendFile(path.resolve(__dirname + '/../public/views/unos.html'));
});
app.get('/osobe', function (req, res) {
    res.sendFile(path.resolve(__dirname + '/../public/views/osobe.html'));
});

app.get('/ucitajRezervacije', function (req, res) {
    let pocetak = req.query.pocetak;
    let kraj = req.query.kraj;
    let salaId = req.query.salaId;
    ucitajRezervacije(pocetak, kraj, salaId).then(result => {
        res.send(result);
    })
});

app.post('/rezervacija', function (req, res) {
    let zauzece = req.body;
    nemaPoklapanja = true;
    //prvo provjerimo da li je sala zauzeta u trazenom terminu
    //moramo provjeriti i u periodicnim i vanrednim zauzecima
    ucitajRezervacije(zauzece.pocetak, zauzece.kraj, zauzece.sala).then(resultSet => {
        //posto smo vec poklopiti vrijeme i salu, samo jos provjeravamo dan/datum
        //prvo provjeravamo u periodicnim zauzecima
        resultSet.periodicna.forEach(element => {
            //ako je zauzece periodicno, samo provjeravamo dan i semestar
            if (zauzece.dan && zauzece.dan == element.dan && zauzece.semestar == element.semestar) {
                nemaPoklapanja = false;
                res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);
            } else if (zauzece.datum && day_en_ba[new Date(zauzece.datum).getDay()] == element.dan) {
                //ako se dan poklapa, provjeravamo i semestar
                if ([1, 2, 3, 4, 5].includes(new Date(zauzece.datum).getMonth()) && element.semestar == 'ljetni') {
                    nemaPoklapanja = false;
                    res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);

                } else if ([0, 9, 10, 11].includes(new Date(zauzece.datum).getMonth()) && element.semestar == 'zimski') {
                    nemaPoklapanja = false;
                    res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);

                } //namjerno razlozeno u vise if-else da je citljivije tokom pregleda
            }
        });
        resultSet.vanredna.forEach(element => {
            //ako je zauzece vanredno, samo datum provjeravamo
            if (zauzece.datum && zauzece.datum == element.datum) {
                nemaPoklapanja = false;
                res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);

            } else {
                //ako je zauzece redovno, provjeravamo prvo dan
                if (zauzece.dan == day_en_ba[new Date(element.datum).getDay()]) {
                    //a onda i semestar
                    if ([1, 2, 3, 4, 5].includes(new Date(element.datum).getMonth()) && zauzece.semestar == 'ljetni') {
                        nemaPoklapanja = false;
                        res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);

                    } else if ([0, 9, 10, 11].includes(new Date(element.datum).getMonth()) && zauzece.semestar == 'zimski') {
                        nemaPoklapanja = false;
                        res.send(`${element.predavac} je vec zauzeo zeljeni termin!`);

                    }
                }
            }
        });
        //nakon sto smo provjerili da nema poklapanja termina, sad dodajemo rezervaciju u bazu
        if (nemaPoklapanja) {
            //kljucno je da dodavanje nove rezervacije stavimo u uslov
            //jer suprotno onome sto bismo na prvi pogled zakljucili
            //da res.send() zavrsava funkciju, ali to nije tako
            //pa da osiguramo da ce se ovaj blok koda pozvati AKKO je ocekivano, 
            //stavljamo ga u ekplicitni uslov
            db.termin.create({
                redovni: zauzece.dan ? true : false,
                dan: zauzece.dan ? zauzece.dan : null,
                datum: zauzece.datum ? zauzece.datum : null,
                semestar: zauzece.semestar ? zauzece.semestar : null,
                pocetak: zauzece.pocetak,
                kraj: zauzece.kraj
            }).then(t => {
                db.rezervacija.create({
                    termin: t.id,
                    osoba: zauzece.predavac,
                    sala: zauzece.sala
                }).then(() => {
                    //unijeli smo novi termin i novu rezervaciju
                    res.send({ message: 'uspjesno dodana rezervacija' });
                    return;
                })
            })
        }
    });
});

var brojac = 0;
app.get('/ucitajTriSlike', function (req, res) {
    brojac++;
    //jednostavan nacin provjere kad i koliko puta se pozove funkcija kada se testira 3. zadatak
    p = req.query;
    prva = parseInt(p.indeks);
    druga = parseInt(p.indeks) + 1;
    treca = parseInt(p.indeks) + 2;
    obj = {}
    obj["brojSlika"] = Object.keys(slike).length;
    obj[prva] = slike[prva] ? slike[prva] : "//:0";
    obj[druga] = slike[druga] ? slike[druga] : "//:0";
    obj[treca] = slike[treca] ? slike[treca] : "//:0";
    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify(obj));
});
app.get('/agent', function (req, res) {
    let browser = req.useragent.browser;
    let ip = req.ip;
    let f = fs.readFileSync(path.resolve(__dirname + '/../public/js/posjetioci.json'));
    let file = JSON.parse(f);
    let chrome = "CHROME";
    let mozilla = "FIREFOX";
    if (browser.toUpperCase() == chrome) {
        file.agent.chrome++;
    } else if (browser.toUpperCase() == mozilla) {
        file.agent.mozilla++;
    }
    if (!file.ip.includes(ip)) {
        file.ip.push(ip);
    }
    fs.writeFileSync(path.resolve(__dirname + '/../public/js/posjetioci.json'), JSON.stringify(file));
    res.setHeader("Content-Type", "application/json");
    res.send({ agent: { chrome: file.agent.chrome, mozilla: file.agent.mozilla }, ip: file.ip.length });
});
app.get('/osoblje', (req, res) => {
    db.osoblje.findAll().then((resultSet) => {
        osoblje = resultSet
        res.send(osoblje);
    });
});
app.get('/ucitajSale', (req, res) => {
    db.sala.findAll().then((resultSet) => {
        sale = resultSet;
        res.send(sale);
    });
});
app.get('/osobeSale', (req, res) => {
    osobeSale().then(result => {
        res.send(result);
    })
});
app.get('/test', (req, res) => {
    res.end();
});
app.listen(8080);

//ucitava rezervacije iz sale, formatira ih kao u zauzeca.json, zamotava ih u promise i prosljedjuje
function ucitajRezervacije(pocetak, kraj, salaId) {
    return new Promise((resolve, reject) => {
        db.rezervacija.findAll({
            attributes: ['id', 'termin', 'osoba', 'sala'],
            include: [{
                model: db.termin,
                attributes: ['id', 'redovni', 'dan', 'datum', 'semestar', 'pocetak', 'kraj'],
                where: {
                    [Op.or]: [
                        {
                            pocetak: {
                                [Op.gte]: pocetak,
                                [Op.lt]: kraj,
                            }
                        },
                        {
                            kraj: {
                                [Op.gt]: pocetak,
                                [Op.lte]: kraj,
                            }
                        }
                    ]
                }
            },
            {
                model: db.osoblje,
                attributes: ['id', 'ime', 'prezime', 'uloga'],
                required: true,
            },
            {
                model: db.sala,
                attributes: ['id', 'naziv'],
                where: {
                    id: {
                        [Op.eq]: salaId
                    }
                }
            }
            ],
        }).then((resultSet) => {
            //nakon sto primim sve rezervacije iz baze, oblikovacu ih da budu kao i one iz zauzeca.json
            let zauzeca = { periodicna: [], vanredna: [] };
            resultSet.forEach(element => {
                if (element.Termin.redovni) {
                    zauzeca.periodicna.push({
                        dan: element.Termin.dan,
                        semestar: element.Termin.semestar,
                        pocetak: element.Termin.pocetak,
                        kraj: element.Termin.kraj,
                        naziv: element.Sala.naziv,
                        predavac: `${element.Osoblje.ime} ${element.Osoblje.prezime}`

                    });
                } else {
                    zauzeca.vanredna.push({
                        datum: element.Termin.datum,
                        pocetak: element.Termin.pocetak,
                        kraj: element.Termin.kraj,
                        naziv: element.Sala.naziv,
                        predavac: `${element.Osoblje.ime} ${element.Osoblje.prezime}`
                    })
                }
            });
            resolve(zauzeca);
        });
    });
}

function osobeSale() {
    return new Promise((resolve, reject) => {
        now = new Date();
        t = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`
        datum = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
        dan = day_en_ba[now.getDay()];
        db.rezervacija.findAll({
            attributes: [],
            include: [
                {
                    model: db.termin,
                    attributes: [],
                    where: {
                        pocetak: {
                            [Op.lte]: t
                        },
                        kraj: {
                            [Op.gte]: t
                        },
                        [Op.or]: [
                            {
                                dan: {
                                    [Op.eq]: null,
                                },
                                datum: {
                                    [Op.eq]: datum
                                }
                            },
                            {
                                dan: {
                                    [Op.eq]: dan,
                                },
                                datum: {
                                    [Op.eq]: null
                                }
                            }
                        ]
                    }
                },
                {
                    model: db.sala,
                    attributes: ['naziv'],
                    required: true,
                },
                {
                    model: db.osoblje,
                    attributes: ['id', 'ime', 'prezime'],
                    required: true
                }
            ]
        }).then(resultSet => {
            resolve(resultSet);
        });
    });
}
danString = {
    0: 'ponedjeljak',
    1: 'utorak',
    2: 'srijeda',
    3: 'cetvrtak',
    4: 'petak',
    6: 'subota',
    7: 'nedjelja',
}

slike = {
    0: 'https://i.picsum.photos/id/570/400/400.jpg',
    1: 'https://i.picsum.photos/id/571/400/400.jpg',
    2: 'https://i.picsum.photos/id/572/400/400.jpg',
    3: 'https://i.picsum.photos/id/573/400/400.jpg',
    4: 'https://i.picsum.photos/id/574/400/400.jpg',
    5: 'https://i.picsum.photos/id/575/400/400.jpg',
    6: 'https://i.picsum.photos/id/576/400/400.jpg',
    7: 'https://i.picsum.photos/id/577/400/400.jpg',
    8: 'https://i.picsum.photos/id/579/400/400.jpg',
    9: 'https://i.picsum.photos/id/581/400/400.jpg',
    10: 'https://i.picsum.photos/id/370/400/400.jpg',
    11: 'https://i.picsum.photos/id/471/400/400.jpg',
    12: 'https://i.picsum.photos/id/472/400/400.jpg',
    13: 'https://i.picsum.photos/id/473/400/400.jpg',
    14: 'https://i.picsum.photos/id/474/400/400.jpg',
    15: 'https://i.picsum.photos/id/461/400/400.jpg',
    16: 'https://i.picsum.photos/id/476/400/400.jpg',
    17: 'https://i.picsum.photos/id/477/400/400.jpg',
    18: 'https://i.picsum.photos/id/479/400/400.jpg',
    19: 'https://i.picsum.photos/id/481/400/400.jpg',
}
let day_en_ba = {
    0: 6,
    1: 0,
    2: 1,
    3: 2,
    4: 3,
    5: 4,
    6: 5
}

module.exports = app;