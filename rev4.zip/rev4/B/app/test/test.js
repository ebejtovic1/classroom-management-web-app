const app = require('../index.js');
let chai = require('chai');
let chaiHttp = require('chai-http');
let should = chai.should();
chai.use(chaiHttp);


describe('testovi dohvatanje osoblja', () => {

    it('dohvati osoblje', (done) => {
        chai.request(app).get('/osoblje').end((err, res) => {
            res.should.have.status(200);
            res.body.length.should.eql(3);
            done();
        });
    });
});
describe('testovi dohvatanje zauzeca', () => {
    it('provjeri da li se zauzeca vracaju u odgovarajucem obliku', (done) => {
        chai.request(app).get('/ucitajRezervacije?pocetak=12:00&kraj=14:00&salaId=1').end((err, res) => {
            res.should.have.status(200);
            res.body.should.have.property('periodicna');
            res.body.should.have.property('vanredna');
            done();
        })
    });
    it('provjeri da li postoje zauzeca od 12 do 2 u sali 1-11', (done) => {
        chai.request(app).get('/ucitajRezervacije?pocetak=12:00&kraj=14:00&salaId=1').end((err, res) => {
            res.should.have.status(200);
            res.body.periodicna.length.should.least(1);
            res.body.periodicna.length.should.least(1);
            done();
        })
    });
    it('provjeri da li je ispravan odgovor ako je kraj prije pocetka', (done) => {
        chai.request(app).get('/ucitajRezervacije?pocetak=14:00&kraj=12:00&salaId=1').end((err, res) => {
            res.should.have.status(200);
            res.body.should.have.property('periodicna');
            res.body.should.have.property('vanredna');
            done();
        })
    });
    it('da li se azurira nakon dodavanja rezervacije', (done) => {
        chai.request(app).get('/ucitajRezervacije?pocetak=12:00&kraj=14:00&salaId=1').end((err, res) => {
            res.should.have.status(200);
            res.body.periodicna.length.should.eql(1);
            res.body.vanredna.length.should.eql(1);
            let obj = {
                datum: '2020-1-10',
                pocetak: '12:00',
                kraj: '13:00',
                sala: 1,
                predavac: 2
            }
            chai.request(app).post('/rezervacija').type('form')
                .send(obj).end((err, res) => {
                    res.should.have.status(200);
                    res.body.message.should.eql('uspjesno dodana rezervacija');
                    chai.request(app).get('/ucitajRezervacije?pocetak=12:00&kraj=14:00&salaId=1').end((err, res) => {
                        res.should.have.status(200);
                        res.body.periodicna.length.should.eql(1);
                        res.body.vanredna.length.should.eql(2);
                        done();
                    });
                });
        });
    });
});

describe('testovi kreiranja zauzeca', () => {
    it('kreiraj novu ispravnu rezervaciju', (done) => {
        let obj = {
            datum: '2020-1-26',
            pocetak: '18:00',
            kraj: '19:00',
            sala: 2,
            predavac: 3
        }
        chai.request(app).post('/rezervacija').type('form')
            .send(obj).end((err, res) => {
                res.should.have.status(200);
                res.body.message.should.eql('uspjesno dodana rezervacija');
                done();
            });
    });
    it('kreiraj novu neispravnu rezervaciju - ista osoba', (done) => {
        let obj = {
            datum: '2020-1-26',
            pocetak: '18:00',
            kraj: '19:00',
            sala: 2,
            predavac: 3
        }
        chai.request(app).post('/rezervacija').type('form')
            .send(obj).end((err, res) => {
                res.should.have.status(200);
                res.text.should.eql('Test Test je vec zauzeo zeljeni termin!');
                done();
            });
    });

    it('kreiraj novu neispravnu rezervaciju - druga osoba', (done) => {
        let obj = {
            datum: '2020-1-26',
            pocetak: '18:00',
            kraj: '19:00',
            sala: 2,
            predavac: 1
        }
        chai.request(app).post('/rezervacija').type('form')
            .send(obj).end((err, res) => {
                res.should.have.status(200);
                res.text.should.eql('Test Test je vec zauzeo zeljeni termin!');
                done();
            });
    });
});
describe('testovi dohvatanje sala', () => {
    it('dohvati sale', (done) => {
        chai.request(app).get('/ucitajSale').end((err, res) => {
            res.should.have.status(200);
            res.body.length.should.eql(2);
            done();
        });
    });

    it('dohvati osobe koje su trenutno u salama', (done) => {
        chai.request(app).get('/osobeSale').end((err, res) => {
            res.should.have.status(200);
            res.body.length.should.eql(0);
            done();
        });
    });
    it('dodaj zauzece, tako da je osoba u sali trenutno', (done) => {
        let now = new Date();
        //pls nemoj ovo testirati oko ponoci, nemam snage dodavati granicni slucaj :)
        let begin = new Date(now.getTime() - 60000);
        let end = new Date(now.getTime() + 60000);
        let t1 = `${begin.getHours()}:${begin.getMinutes()}:${begin.getSeconds()}`;
        let t2 = `${end.getHours()}:${end.getMinutes()}:${end.getSeconds()}`;
        let datum = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
        let obj = {
            datum: datum,
            pocetak: t1,
            kraj: t2,
            sala: 1,
            predavac: 2
        }
        chai.request(app).post('/rezervacija').type('form')
            .send(obj).end((err, res) => {
                res.should.have.status(200);
                res.body.message.should.eql('uspjesno dodana rezervacija');
                chai.request(app).get('/osobeSale').end((err, res) => {
                    res.should.have.status(200);
                    res.body.length.should.eql(1);
                    done();
                });
            });
    });
});
