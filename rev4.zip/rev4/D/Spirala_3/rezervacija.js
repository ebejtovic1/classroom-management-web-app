window.onload=function(){
   
   Pozivi.ucitajZauzeca();
   Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), new Date().getMonth());
   document.getElementById("unos").addEventListener("click",function(){Kalendar.ucitajSaForme();})
   document.getElementById("prethodni").addEventListener("click",function(){Kalendar.prethodni();})
   document.getElementById("sljedeci").addEventListener("click",function(){Kalendar.sljedeci();})
    
        // dodato
        var classname = document.getElementsByClassName("dani"); // uzimamo sve dane
   
        for (var i = 0; i < classname.length; i++) { 
            classname[i].addEventListener("click", klikNaCeliju, false);
        }

}





function dajSemestar(mjesec) {
    if(mjesec == "Oktobar" || mjesec == "Novembar" || mjesec == "Decembar" || mjesec == "Januar")
        return "zimski";

    else if(mjesec == "Februar" || mjesec == "Mart" || mjesec == "April" || mjesec == "Maj")
        return ljetni;

    return "nijedan";
}


function dajRedniBrojMjeseca(mjesec) {
    if(mjesec == "Januar")
        return 1;
    if(mjesec == "Februar")
        return 2;
    if(mjesec == "Mart")
        return 3;
    if(mjesec == "April")
        return 4;
    if(mjesec == "Maj")
        return 5;
    if(mjesec == "Juni")
        return 6;
    if(mjesec == "Juli")
        return 7;
    if(mjesec == "August")
        return 8;
    if(mjesec == "Septembar")
        return 9;
    if(mjesec == "Oktobar")
        return 10;
    if(mjesec == "Novembar")
        return 11;
    if(mjesec == "Decembar")
        return 12;

    return 13;
}


var klikNaCeliju = function() {
    var klaseCelije = this.getAttribute("class");
    if(klaseCelije.includes("slobodna")) { // samo ako je slobodna

        var zelimRezervaciju = confirm("Zelite li rezervisati ovu salu?");
        if(zelimRezervaciju) {
            var periodicna = document.getElementById('periodicna');
            var nazivSale = document.getElementById('dropdownList').value;
            var pocetak = document.getElementById('pocetak').value;
            var kraj = document.getElementById('kraj').value;
            var dan = parseInt(this.innerHTML);
            var mjesec = document.getElementById("mojKalendar").caption.innerText; // naziv mjeseca (npr. "Januar")
            
            var semestar = dajSemestar(mjesec); // ljetni, zimski ili nijedan
            
            var godina = 2019 // smatramo da je uvijek 2019
            var mjesecBroj = dajRedniBrojMjeseca(mjesec); // "Januar" -> 1

            var datumVanredna = dan.toString() + "." + mjesecBroj.toString() + "." + godina.toString();
            var sveOk = Kalendar.validiraj(nazivSale, pocetak, kraj) && mjesecBroj != 13;
            
            if(sveOk) {
                var rezervacija;
                if(periodicna && semestar!="nijedan") {
                    rezervacija = {
                        "dan": dan,
                        "semestar": semestar,
                        "pocetak": pocetak,
                        "kraj": kraj,
                        "naziv": nazivSale,
                        "predavac": "" // ne znamo ko je predavac
                    }
                }
                else {
                    rezervacija = {
                        "datum": datumVanredna,
                        "pocetak": pocetak,
                        "kraj": kraj,
                        "naziv": nazivSale,
                        "predavac": "" // ne znamo ko je predavac
                    }

                }
                console.log(rezervacija);
            Pozivi.rezervisiSalu(rezervacija)
            }

            else {
                alert("Niste unijeli ispravne podatke!")
            }
        }

    }
};

