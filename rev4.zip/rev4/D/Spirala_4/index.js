const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require('path');
const url = require('url');
const db = require('./db.js');
const Kalendar = require('./kalendar.js');
const Op = db.Sequelize.Op;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(__dirname));

async function dajIdOsobe(naziv) {

    // pretpostavljamo da ne mogu postojati u bazi dvije osobe sa
    // istim nazivom

    // naziv je u formatu "ime prezime (uloga)"

    let imePrezimeUloga = naziv.split(" ");
    let ime = imePrezimeUloga[0];
    let prezime = imePrezimeUloga[1];
    let uloga = imePrezimeUloga[2];
    uloga = uloga.replace("(", "");
    uloga = uloga.replace(")", "");


    let trazenaOsoba = await db.osoblje.findOne({where:{ime: ime, prezime: prezime, uloga: uloga}});

    return trazenaOsoba.getDataValue("id");

}


async function dajIdSale(naziv) {

    // pretpostavljamo da ne mogu istovremeno postojati dvije sale u bazi sa istim nazivom
    // iz naziva dobivamo id
    let trazenaSala = await db.sala.findOne({where:{naziv: naziv}});

    return trazenaSala.getDataValue("id");

}

async function dajSvaZauzeca() {

    var dan = null;
    var datum = null;
    var nazivSale = null;
    var predavac = null;
    var pocetak = null;
    var kraj = null;
    var redovni = null;
    var semestar = null;
    var periodicna = [];
    var vanredna = [];
    var svaZauzeca = [];    


    let sveRezervacije = await db.rezervacija.findAll();

    for (var i = 0; i<sveRezervacije.length; i++) {
        let rezervacija = sveRezervacije[i];

            // nalazimo termin
            let termin = await db.termin.findOne({where:{id:rezervacija.termin}});
                redovni = termin.getDataValue("redovni");
                pocetak = termin.getDataValue("pocetak");
                kraj = termin.getDataValue("kraj");
                if(redovni == true) {
                    dan = termin.getDataValue("dan");
                    semestar = termin.getDataValue("semestar");
                }
                else {
                    datum = termin.getDataValue("datum");
                }

            // nalazimo salu
            let sala = await db.sala.findOne({where:{id:rezervacija.sala}});
                nazivSale = sala.getDataValue("naziv");


            // nalazimo osobu/predavaca
            let osoba = await db.osoblje.findOne({where:{id:rezervacija.osoba}});
                predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") + ")";

            if(redovni == true) {
                var rezervacijaUpis = {
                    "dan": dan,
                    "semestar": semestar,
                    "pocetak": pocetak,
                    "kraj": kraj,
                    "naziv": nazivSale,
                    "predavac": predavac 
                }

                periodicna.push(rezervacijaUpis);
            }
            else {
                var rezervacijaUpis = {
                "datum": datum,
                "pocetak": pocetak,
                "kraj": kraj,
                "naziv": nazivSale,
                "predavac": predavac
                }

                vanredna.push(rezervacijaUpis);
            }

        }



    svaZauzeca = {"periodicna":periodicna, "vanredna":vanredna}
    return svaZauzeca;

}

async function ubaciNovoZauzece(rezervacija) {

    // rezervacija je tijelo POST zahtjeva u json formatu

    let nazivPredavaca = rezervacija["predavac"];
    let nazivSale = rezervacija["naziv"];


    let idPredavaca = await dajIdOsobe(nazivPredavaca);
    let idSale = await dajIdSale(nazivSale);

    let sviTermini = await db.termin.findAll();
    let brojTermina = sviTermini.length;
    let noviIdTermina = brojTermina + 1;

    let noviTermin = null;

    if(Object.keys(rezervacija).length == 6) { // ako je periodicna rezervacija

        noviTermin = {
            id: noviIdTermina,
            redovni: true,
            dan: rezervacija["dan"],
            datum: null,
            semestar: rezervacija["semestar"],
            pocetak: rezervacija["pocetak"],
            kraj: rezervacija["kraj"]
        }
    }
        
    else { // ako je vanredna

        noviTermin = {
            id: noviIdTermina,
            redovni: false,
            dan: null,
            datum: rezervacija["datum"],
            semestar: null,
            pocetak: rezervacija["pocetak"],
            kraj: rezervacija["kraj"]
        }
        
    }

    // u create saljemo json format kolona: vrijednost
    
    let sveRezervacije = await db.rezervacija.findAll();
    let brojRezervacija = sveRezervacije.length;
    let noviIdRezervacije = brojRezervacija + 1;

    let novaRezervacija = {id: noviIdRezervacije, termin: noviIdTermina, sala: idSale, osoba: idPredavaca};
    

    await db.termin.create(noviTermin); // ubacivanje novog termina
    await db.rezervacija.create(novaRezervacija) // ubacivanje nove rezervacije

    let svaZauzeca = await dajSvaZauzeca();
    return svaZauzeca;

    
}


app.get('/zauzeca', async (req, res) => {
    var rezultat = await dajSvaZauzeca();
    res.send(rezultat);
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'pocetna.html'));
});


app.get('/svoOsoblje',(req,res) => {

    return db.osoblje.findAll().then(function(svoOsoblje){
        res.send(svoOsoblje);
    });
     
});

app.get('/sveSale',(req,res) => {

    return db.sala.findAll().then(function(sveSale){
        res.send(sveSale);
    });
     
});



app.post('/zauzeca', async (req, res) => {

    let rezervacija = req.body;

    let imaZauzece = false;
    let pocetak;
    let kraj;
    let nazivSale;
    let svaZauzeca = null;
    let redovni;
    let semestar;
    let dan;
    let datum;

    let rezervacijaPocetak = rezervacija["pocetak"];
    let rezervacijaKraj = rezervacija["kraj"];
    let rezervacijaDan;
    let rezervacijaSemestar;
    let rezervacijaDatum;
    let rezervacijaNazivSale = rezervacija["naziv"];
    let rezervacijaRedovni = false;
    if(Object.keys(rezervacija).length == 6) { // ako je periodicna rezervacija
        rezervacijaRedovni = true;
        rezervacijaDan = rezervacija["dan"];
        rezervacijaSemestar = rezervacija["semestar"];
    }
    else {
        rezervacijaDatum = rezervacija["datum"];
    }

    let tekst = "Osoba koja je zauzela salu: ";

    let sveRezervacije = await db.rezervacija.findAll();

    for (var i = 0; i<sveRezervacije.length; i++) {

        let rezervacijaBaza = sveRezervacije[i];

        // nalazimo termin
        let termin = await db.termin.findOne({where:{id:rezervacijaBaza.termin}});

        redovni = termin.getDataValue("redovni");
        pocetak = termin.getDataValue("pocetak");
        kraj = termin.getDataValue("kraj");
        if(redovni == true) {
            dan = termin.getDataValue("dan");
            semestar = termin.getDataValue("semestar");
        }
        else {
            datum = termin.getDataValue("datum");
        }

        // nalazimo salu
        let sala = await db.sala.findOne({where:{id:rezervacijaBaza.sala}});
        nazivSale = sala.getDataValue("naziv");

        if(redovni && rezervacijaRedovni) {

            if(nazivSale == rezervacijaNazivSale && dan == rezervacijaDan && semestar == rezervacijaSemestar && Kalendar.imaPresjek(pocetak, kraj, rezervacijaPocetak, rezervacijaKraj)) {
                imaZauzece = true;
                // nalazimo osobu/predavaca
                let osoba = await db.osoblje.findOne({where:{id:rezervacijaBaza.osoba}});
                let predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") +")";
                tekst += predavac;
            }
        }
        else if(redovni && !rezervacijaRedovni) {


            let danSemestar = Kalendar.dajDanISemestar(rezervacijaDatum);
            if(nazivSale == rezervacijaNazivSale && dan == danSemestar[0] && semestar == danSemestar[1] && Kalendar.imaPresjek(pocetak, kraj, rezervacijaPocetak, rezervacijaKraj)) {
                imaZauzece = true;
                // nalazimo osobu/predavaca
                let osoba = await db.osoblje.findOne({where:{id:rezervacijaBaza.osoba}});
                let predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") +")";
                tekst += predavac;
            }
        }
        else if(!redovni && rezervacijaRedovni) {

            let danSemestar = Kalendar.dajDanISemestar(datum);
            if(nazivSale == rezervacijaNazivSale && danSemestar[0] == rezervacijaDan && danSemestar[1] == rezervacijaSemestar && Kalendar.imaPresjek(pocetak, kraj, rezervacijaPocetak, rezervacijaKraj)) {
                imaZauzece = true;
                // nalazimo osobu/predavaca
                let osoba = await db.osoblje.findOne({where:{id:rezervacijaBaza.osoba}});
                let predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") +")";
                tekst += predavac;
            }
        }
        else {
            if(nazivSale == rezervacijaNazivSale && datum == rezervacijaDatum && Kalendar.imaPresjek(pocetak, kraj, rezervacijaPocetak, rezervacijaKraj)) {
                imaZauzece = true;
                // nalazimo osobu/predavaca
                let osoba = await db.osoblje.findOne({where:{id:rezervacijaBaza.osoba}});
                let predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") +")";
                tekst += predavac;
                console.log(tekst)
            }

        }
    
    }

    if(imaZauzece) {
        console.log("sala je zauzeta!");
        svaZauzeca = tekst;
    }

    else {
        console.log("sala nije zauzeta");
        svaZauzeca = await ubaciNovoZauzece(rezervacija);
    }

    res.send(svaZauzeca);

 
});



async function imaJosPojavljivanja(indeks, trazeniId) {

    let sveRezervacije = null;
    sveRezervacije = await db.rezervacija.findAll();

    var rez = [];
    for (var i = 0; i< sveRezervacije.length; i++) {
        var id = (sveRezervacije[i]).getDataValue('osoba');
        rez.push(id);
    }

    console.log("indeks = " + indeks, ", tid = " + trazeniId);
    console.log("rez = " + rez);

    for(var i = indeks + 1; i<rez.length; i++){
        if(rez[i] == trazeniId)
            return 1;
    }

    return 0;


}


// funkcija vraća niz json objekata {naziv: "ime prezime (uloga)", sala: "kancelarija"}
// za svo osoblje koje trenutno nema rezervaciju
async function dajOsobeBezRezervacije() {

    let idOsobaSaRezervacijom = null;
    idOsobaSaRezervacijom = await db.rezervacija.findAll({
        attributes: ['osoba']
    });

    var rez = [];
    for (var i = 0; i< idOsobaSaRezervacijom.length; i++) {
        var id = idOsobaSaRezervacijom[i].getDataValue('osoba');
        rez.push(id);
    }

    let osobeBezRezervacije = await db.osoblje.findAll({
        where: {
            id: {[Op.notIn]: rez}
        },
        attributes: ['ime', 'prezime', 'uloga']
    });


    rez = [];

    for (var i = 0; i< osobeBezRezervacije.length; i++) {
        var ime = osobeBezRezervacije[i].getDataValue('ime');
        var prezime = osobeBezRezervacije[i].getDataValue('prezime');
        var uloga = osobeBezRezervacije[i].getDataValue('uloga');
        var naziv = ime + " " + prezime + " (" + uloga + ")";
        var objekat = {nazivPredavaca: naziv, nazivSale: "kancelarija"}
        rez.push(objekat);
    }


    return rez;

}


async function osobaRezervacija() {


    var dan = null;
    var datum = null;
    var nazivSale = null;
    var predavac = null;
    var pocetak = null;
    var kraj = null;
    var redovni = null;
    var semestar = null;

    let rezSa = [];
    let rezBez = [];



    let sveRezervacije = await db.rezervacija.findAll();

    

    for (var i = 0; i<sveRezervacije.length; i++) {
            let rezervacija = sveRezervacije[i];

            // nalazimo termin
            let termin = await db.termin.findOne({where:{id:rezervacija.termin}});
                redovni = termin.getDataValue("redovni");
                pocetak = termin.getDataValue("pocetak");
                kraj = termin.getDataValue("kraj");

               
                if(redovni == true) {
                    dan = termin.getDataValue("dan");
                    semestar = termin.getDataValue("semestar");
                }
                else {
                    datum = termin.getDataValue("datum");
                }

            // nalazimo salu
            let sala = await db.sala.findOne({where:{id:rezervacija.sala}});
                nazivSale = sala.getDataValue("naziv");

                // nalazimo osobu/predavaca
                let osoba = await db.osoblje.findOne({where:{id:rezervacija.osoba}});
                    predavac = osoba.getDataValue("ime") + " " + osoba.getDataValue("prezime") + " (" + osoba.getDataValue("uloga") + ")";

                var presjek = Kalendar.imaPresjek(Kalendar.dajTrenutnoVrijeme(), Kalendar.dajTrenutnoVrijeme(), pocetak, kraj);

                var ponovo = await imaJosPojavljivanja(i,rezervacija.osoba);
                console.log("osoba id = " + rezervacija.osoba + ", ponovo = " + ponovo);

                if(presjek) {
                    
                    danSemestar = Kalendar.dajDanISemestar(Kalendar.dajTrenutniDatum());
                    if( (redovni && dan == danSemestar[0]) || (!redovni && datum == Kalendar.dajTrenutniDatum()) ) {
                        var objekat = {nazivPredavaca: predavac, nazivSale: nazivSale};
                        rezSa.push(objekat);
                    }
                    else if (!ponovo) {
                        var objekat = {nazivPredavaca: predavac, nazivSale: "kancelarija"};
                        rezBez.push(objekat);
                    }
                }

                else if (!ponovo) {
                    var objekat = {nazivPredavaca: predavac, nazivSale: "kancelarija"};
                    rezBez.push(objekat);
                }
            

            

    }

    let bezIkakveRezervacije = await dajOsobeBezRezervacije();
    rezBez = rezBez.concat(bezIkakveRezervacije);

    let rez = rezSa.concat(rezBez);
    return rez;


}


app.get('/osoblje', async (req, res) => {
    var rez = await osobaRezervacija();
    let tekst = "";
    for(var i = 0; i< rez.length; i++){
        var el = rez[i];
        if(el.nazivSale == "kancelarija")
            tekst += "<p>" + el.nazivPredavaca + " se nalazi u kancelariji.</p>";
        else
            tekst += "<p>" + el.nazivPredavaca + " se nalazi u " + el.nazivSale + ".</p>";
    }

    res.send(tekst);
});



app.listen(8080);

