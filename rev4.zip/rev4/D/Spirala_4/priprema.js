const db = require('./db.js')
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});


function inicializacija(){
    var osoba1, osoba2, osoba3;
    var osobeListaPromisea = [];
    var saleListaPromisea = [];
    var rezervacijeListaPromisea = [];
    var terminiListaPromisea = [];

    return new Promise(function(resolve,reject){

    osobeListaPromisea.push(db.osoblje.create({ id: 1, ime: "Neko", prezime: "Nekic", uloga: "profesor" }));
    osobeListaPromisea.push(db.osoblje.create({ id: 2, ime: "Drugi", prezime: "Neko", uloga: "asistent" }));
    osobeListaPromisea.push(db.osoblje.create({ id: 3, ime: "Test", prezime: "Test", uloga: "asistent" }));

    terminiListaPromisea.push(db.termin.create({id:1, redovni:false, dan:null, datum:"01.01.2020", semestar:null, pocetak:"12:00", kraj:"13:00"}));
    terminiListaPromisea.push(db.termin.create({id:2, redovni:true, dan:0, datum:null, semestar:"zimski", pocetak:"13:00", kraj:"14:00"}));


    Promise.all(osobeListaPromisea).then(function(osobe){

        var neko = osobe.filter(function(a){return a.id===1})[0];
        var drugi = osobe.filter(function(a){return a.id===2})[0];
        var test = osobe.filter(function(a){return a.id===3})[0];


        saleListaPromisea.push(
            db.sala.create({id:1, naziv:"1-11", zaduzenaOsoba:1}).then(function(k){
                k.setDataValue("zaduzenaOsoba", neko);
                return new Promise(function(resolve,reject){resolve(k);});
            })
        );

        saleListaPromisea.push(
            db.sala.create({id:2, naziv:"1-15", zaduzenaOsoba:2}).then(function(k){
                k.setDataValue("zaduzenaOsoba", drugi);
                return new Promise(function(resolve,reject){resolve(k);});
            })
        );
    }).catch(function(err){console.log("Osoblje greska prva iteracija "+err);}); 

        
    Promise.all(osobeListaPromisea).then(function(osobe){

        var neko = osobe.filter(function(a){return a.id===1})[0];
        var drugi = osobe.filter(function(a){return a.id===2})[0];
        var test = osobe.filter(function(a){return a.id===3})[0];

        Promise.all(terminiListaPromisea).then(function(termini){
            var t1=termini.filter(function(k){return k.id===1})[0];
            var t2=termini.filter(function(k){return k.id===2})[0];

            Promise.all(saleListaPromisea).then(function(sale){
                var sala1 = sale.filter(function(a){return a.id===1})[0];
                var sala2 = sale.filter(function(a){return a.id===2})[0];

                rezervacijeListaPromisea.push(
                    db.rezervacija.create({id:1, termin:1, sala:1, osoba:1}).then(function(r){
                        r.setDataValue("termin", t1);
                        r.setDataValue("sala", sala1);
                        r.setDataValue("osoba", neko);
                        return new Promise(function(resolve,reject){resolve(r);});
                        
                    })
                );

                rezervacijeListaPromisea.push(
                    db.rezervacija.create({id:2, termin:2, sala:1, osoba:3}).then(function(r){
                        r.setDataValue("termin", t2);
                        r.setDataValue("sala", sala2);
                        r.setDataValue("osoba", test);
                        return new Promise(function(resolve,reject){resolve(r);});
                    })
                );

                Promise.all(rezervacijeListaPromisea).then(function(r){resolve(r);}).catch(function(err){console.log("Rezervacije greska druga iteracija"+err);});

            }).catch(function(err){console.log("Sale greska druga iteracija"+err);});

            
        }).catch(function(err){console.log("Termini greska druga iteracija"+err);});


    }).catch(function(err){console.log("Osoblje greska druga iteracija"+err);});

    });
}







