// ******************************REZERVACIJA****************************************************************
const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {


    const Rezervacija = sequelize.define('Rezervacija', {
        id:{
            type: Sequelize.INTEGER,
            allowNull: false,
            primaryKey: true
        }
    },
    {
        freezeTableName: true 
    });
    return Rezervacija;

};
//module.exports = Rezervacija;


