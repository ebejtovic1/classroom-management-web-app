let Pozivi = (function() {


        function ucitajZauzecaImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {
                    var sveRezervacije = JSON.parse(ajax.responseText);
                    mojaPeriodicna = sveRezervacije["periodicna"];
                    mojaVanredna = sveRezervacije["vanredna"];
                }
            }
            ajax.open("GET","http://localhost:8080/zauzeca",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
        }


        // upis u dropdown listu osoblja
        function ucitajSvoOsobljeImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {

                    var mojeOsoblje = JSON.parse(ajax.response); // dodao var
                    var osoblje = document.getElementById("osoblje");

                        osoblje.innerHTML = '<option value="">-</option>';
                        
                        for (var i = 0; i<mojeOsoblje.length; i++) {
                            var ime = mojeOsoblje[i]["ime"];
                            var prezime = mojeOsoblje[i]["prezime"];
                            var uloga = mojeOsoblje[i]["uloga"];
                            osoblje.innerHTML += '<option value="' + i+1 + '">' + ime + ' ' + prezime + ' (' + uloga + ')</option>'
                        }
                }
           }
           ajax.open("GET","http://localhost:8080/svoOsoblje",true);
           ajax.setRequestHeader("Content-Type", "application/json");
           ajax.send();
           
        }

        // azuriranje prikaza stranice /osoblje
        function ucitajOsobljeRezervacijaImpl(){

            var ajax = new XMLHttpRequest();
            ajax.open("GET","http://localhost:8080/osoblje",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
            
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {
                    // ništa...
                }
           }


        }

        setInterval(ucitajOsobljeRezervacijaImpl, 30000);


        
        
        function ucitajPocetnaImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
               if (ajax.readyState == 4 && ajax.status == 200){
                    // ništa...
               }
           }
           ajax.open("GET","http://localhost:8080/",true);
           ajax.setRequestHeader("Content-Type", "text/html");
           ajax.send();
        }



        // rezervacija je JSON objekat
        function rezervisiSaluImpl(rezervacija) {
            // saljemo POST zahtjev na server (/zauzeca)
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
               if (ajax.readyState == 4 && ajax.status == 200){
                    // kada nam server vrati odgovor
                    var odgovor = ajax.response;

                    if(odgovor.includes("Osoba")) {
                            poruka = odgovor;
                            alert(poruka);
                    }
                    else {
                            odgovor = JSON.parse(odgovor);
                            mojaPeriodicna = odgovor["periodicna"]; // azuriramo zauzeca
                            mojaVanredna = odgovor["vanredna"];
                            Kalendar.ucitajSaForme();
                    }
                }
           }
           ajax.open("POST","http://localhost:8080/zauzeca",true);
           ajax.setRequestHeader("Content-Type", "application/json");
           ajax.send(JSON.stringify(rezervacija)); // moramo poslati string kao parametar
        }

        // upis u dropdown listu sala
        function ucitajSveSaleImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {

                    var mojeSale = JSON.parse(ajax.response); // dodao var
                    var sale = document.getElementById("sale");

                        sale.innerHTML = '<option value="">-</option>';
                        
                        for (var i = 0; i<mojeSale.length; i++) {
                            var naziv = mojeSale[i]["naziv"];
                            sale.innerHTML += '<option value="' + i+1 + '">' + naziv + '</option>'
                        }
                }
           }
           ajax.open("GET","http://localhost:8080/sveSale",true);
           ajax.setRequestHeader("Content-Type", "application/json");
           ajax.send();
           
        }


    
        return {
            ucitajZauzeca: ucitajZauzecaImpl,
            ucitajPocetna: ucitajPocetnaImpl,
            rezervisiSalu: rezervisiSaluImpl,
            ucitajSvoOsoblje: ucitajSvoOsobljeImpl,
            ucitajOsobljeRezervacija: ucitajOsobljeRezervacijaImpl,
            ucitajSveSale: ucitajSveSaleImpl
        }

    }());


