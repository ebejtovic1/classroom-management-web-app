let Kalendar = (function(){

    var mojKalendar;
    var mojaPeriodicna = [];
    var mojaVanredna = []; 
    var trenutniMjesec = new Date().getMonth();
    var trenutnaGodina = new Date().getFullYear();

    var mjeseci = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
    
    function dajMjesec(i) { return mjeseci[i]; }

    
    function dajDan(i) {
        switch (i) {
            case 0:
              var day = "PON";
              break;
            case 1:
              day = "UTO";
              break;
            case 2:
               day = "SRI";
              break;
            case 3:
              day = "ČET";
              break;
            case 4:
              day = "PET";
              break;
            case 5:
              day = "SUB";
              break;
            case 6:
              day = "NED";
        }
        
        return day;
    }

    function danaUMjesecu(mjesec, godina) {
        return 32 - new Date(godina, mjesec, 32).getDate();
    }

    
    function sljedeciImpl() {

        if(trenutniMjesec == 11) {
            return;
        }
        else 
            trenutniMjesec++;

        ucitajSaFormeImpl();
    }

    function prethodniImpl() {

        if(trenutniMjesec == 0) {
            return;
        }
        else
            trenutniMjesec--;

        ucitajSaFormeImpl();
    }

    

    function dajSemestar(mjesec) {
        if(mjesec == 0 || mjesec == 9 || mjesec == 10 || mjesec == 11)
            return "zimski";
        else if(mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4)
            return "ljetni";
        
        return "nijedan";
    }

    //hh:mm je format stringova
    function imaPresjek(pocetak1, kraj1, pocetak2, kraj2) {

        //pocetak1 10:30
        var terminPocetak1 = pocetak1.split(":"); // ["10","30"]
        //kraj1 12:30
        var terminKraj1 = kraj1.split(":"); // ["12","30"]

        var pocetakSatiBroj1 = parseInt(terminPocetak1[0], 10); // 10
        var pocetakMinutaBroj1 = parseInt(terminPocetak1[1], 10); // 30
        var krajSatiBroj1 = parseInt(terminKraj1[0], 10); // 12
        var krajMinutaBroj1 = parseInt(terminKraj1[1], 10); // 30

        //******************************************************************


        //pocetak2 09:30
        var terminPocetak2 = pocetak2.split(":"); // ["09","30"]
        //kraj2 11:30
        var terminKraj2 = kraj2.split(":"); // ["11","30"]

        var pocetakSatiBroj2 = parseInt(terminPocetak2[0], 10); // 9
        var pocetakMinutaBroj2 = parseInt(terminPocetak2[1], 10); // 30
        var krajSatiBroj2 = parseInt(terminKraj2[0], 10); // 11
        var krajMinutaBroj2 = parseInt(terminKraj2[1], 10); // 30

        

        // U ovom slučaju ima preklapanje


        // Dijeljenje dva cijela broja ne vraća uvijek cijeli broj

        var pocTacka1 = pocetakSatiBroj1 + pocetakMinutaBroj1/60;
        var krajTacka1 = krajSatiBroj1 + krajMinutaBroj1/60;
        
        var pocTacka2 = pocetakSatiBroj2 + pocetakMinutaBroj2/60;
        var krajTacka2 = krajSatiBroj2 + krajMinutaBroj2/60;


        // Ako jedan termin završava kad drugi počinje to smatramo da nije preklapanje
        if(krajTacka1 <= pocTacka2 || krajTacka2 <=  pocTacka1)
            return false;

        return true;



    }


    // zazuzetiDan je kolona
    function obojiKolonu(kalendarRef, zauzetiDan) {

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                var mijenjati = !(celija.classList.contains("border-less"));
                if(j == zauzetiDan && mijenjati) {
                    celija.classList.remove("slobodna");
                    celija.classList.add("zauzeta");
                    break;// jer je max jednom sedmično
                }
            }
        }

    }

    // dan je redni broj dana
    function obojiCeliju(kalendarRef, dan) {

        var brojac = 0;


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                var mijenjati = !(celija.classList.contains("border-less"));
                if(mijenjati) {
                    brojac++;
                    if(brojac == dan) {
                        celija.classList.remove("slobodna");
                        celija.classList.add("zauzeta");
                        return; // jer je jednom mjesečno
                    }
                }
            }
        }

    }

    
    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
        
    
        mojKalendar = kalendarRef;
        
        var semestar = dajSemestar(mjesec);

        
        var arrayLengthPeriodicna = mojaPeriodicna.length;
        var arrayLengthVanredna = mojaVanredna.length;

        
        

            

            for (var i = 0; i < arrayLengthPeriodicna; i++) {
                if(mojaPeriodicna[i].naziv == sala && mojaPeriodicna[i].semestar == semestar && imaPresjek(pocetak, kraj, mojaPeriodicna[i].pocetak, mojaPeriodicna[i].kraj) && mjesec == trenutniMjesec) {
                    var zauzetiDanBroj = mojaPeriodicna[i].dan; // broj u rasponu [0,6]
                    obojiKolonu(kalendarRef, zauzetiDanBroj);
                }
            }

            

            for (var i = 0; i < arrayLengthVanredna; i++) {
                var zauzetiDatum = mojaVanredna[i].datum;
                var danMjesecGodina = zauzetiDatum.split(".");
                if(mojaVanredna[i].naziv == sala  && imaPresjek(pocetak, kraj, mojaVanredna[i].pocetak, mojaVanredna[i].kraj) && danMjesecGodina[1]-1 == mjesec && danMjesecGodina[2] == trenutnaGodina && mjesec == trenutniMjesec) {
                    obojiCeliju(kalendarRef, danMjesecGodina[0]);
                }
            }

        


    }




    function ucitajPodatkeImpl(periodicna, vanredna) {
        mojaPeriodicna = periodicna;
        mojaVanredna = vanredna;
    }


    function validiraj(sala, pocetak, kraj) {
        var ok = new Boolean(true);

        if(sala == null || sala == "" || pocetak == null || pocetak == "" || kraj == null || kraj == "")
            ok = false;


        return ok.valueOf();
    }


    function ucitajSaFormeImpl(){

        nazivSale = document.getElementById('dropdownList').value;
        pocetak = document.getElementById('pocetak').value;
        kraj = document.getElementById('kraj').value;

        iscrtajKalendarImpl(document.getElementById("mojKalendar"), trenutniMjesec);
        // bojimo zauzece sale

        sveOk = validiraj(nazivSale, pocetak, kraj);

        if(sveOk)
            obojiZauzecaImpl(document.getElementById("mojKalendar"), trenutniMjesec, nazivSale, pocetak, kraj);

        
    }
    


    function iscrtajKalendarImpl(kalendarRef, mjesec) {

        mojKalendar = kalendarRef;

        trenutniMjesec = mjesec;



        let prviDan = (new Date(trenutnaGodina, mjesec)).getDay() - 1;

        if(prviDan < 0)
            prviDan += 7;


        // "brišemo" stari mjesec
        kalendarRef.innerHTML = "";

        var caption = kalendarRef.createCaption();
            
        var nazivMjeseca = dajMjesec(mjesec);
        caption.innerHTML = "<b>" + nazivMjeseca + "</b>";

        let daniUSedmici = document.createElement("tr");

        for(let i = 0; i < 7; i++) {
            var celija = document.createElement("td");
            var celijaText = document.createTextNode(dajDan(i));
            celija.appendChild(celijaText);
            daniUSedmici.appendChild(celija);
        }

        kalendarRef.appendChild(daniUSedmici);

        
        let trenutniDan = 1;
        for (let i = 0; i < 6; i++) {
            
            let red = document.createElement("tr");

            
            for (let j = 0; j < 7; j++) {
                if (i === 0 && j < prviDan) {
                    celija = document.createElement("td");
                    celijaText = document.createTextNode("");
                    celija.classList.add("border-less"); // ne prikazujemo ove dane
                    celija.appendChild(celijaText);
                    red.appendChild(celija);
                }
                else if (trenutniDan > danaUMjesecu(mjesec, trenutnaGodina)) {
                    break;
                }

                else {
                    celija = document.createElement("td");
                    celijaText = document.createTextNode(trenutniDan);
                    celija.classList.add("slobodna"); // po defaultu su svi slobodni
                    celija.classList.add("dani");
                    celija.appendChild(celijaText);
                    red.appendChild(celija);
                    trenutniDan++;
                }


            }

            kalendarRef.appendChild(red);
        }

    }


           
    return {

        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl,
        prethodni: prethodniImpl,
        sljedeci: sljedeciImpl,
        ucitajSaForme: ucitajSaFormeImpl,
        danaUMjesecu: danaUMjesecu
    } 
                
}());



/*

let periodicna = [
    {
        dan: 4,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "10:30",
        naziv: "0-01",
        predavac: "Richard Feynman"
    },

    {
        dan: 2,
        semestar: "zimski",
        pocetak: "14:00",
        kraj: "15:00",
        naziv: "0-02",
        predavac: "Nikola Tesla"
    },

    {
        dan: 1,
        semestar: "ljetni",
        pocetak: "15:00",
        kraj: "17:00",
        naziv: "VA1",
        predavac: "Arhimed"
    },

    {
        dan: 4,
        semestar: "ljetni",
        pocetak: "16:00",
        kraj: "17:30",
        naziv: "MA",
        predavac: "Albert Einstein"
    }
];
*/

/*

let vanredna = [
    {
        datum: "23.11.2019",
        pocetak: "09:00",
        kraj: "12:00",
        naziv: "0-01",
        predavac: "Eustahije Brzić"
    },

    {
        datum: "24.12.2019",
        pocetak: "14:00",
        kraj: "15:00",
        naziv: "0-01",
        predavac: "Janko Strižić"
    },

    {
        datum: "18.10.2019",
        pocetak: "17:00",
        kraj: "17:45",
        naziv: "EE1",
        predavac: "Eustahije Brzić"
    }

];
*/


//window.onload = function () {
//Prikazujemo trenutni mjesec
// Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), new Date().getMonth());
/*
// ucitavamo podatke
Kalendar.ucitajPodatke(periodicna,vanredna);
//}
*/

