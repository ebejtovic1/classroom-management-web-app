const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes){
    const Rezervacija = sequelize.define("Rezervacija", {
        id:{ 
            type:Sequelize.INTEGER,
            primaryKey:true,
            autoIncrement:true
        },//PK
        termin:{ 
            type:Sequelize.INTEGER,
            references:{
                model:"Termin",
                key:"id"
            },
            unique: true
        }, //FK unique
        sala:{ 
            type:Sequelize.INTEGER,
            references:{
                model:"Sala",
                key:"id"
            }
        }, //FK
        osoba:{ 
            type:Sequelize.INTEGER,
            references:{
                model:"Osoblje",
                key:"id"
            }
        } //FK
    },
    {freezeTableName: true});

    return Rezervacija;
}