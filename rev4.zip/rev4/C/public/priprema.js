const db = require("./db.js");
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i inicijaliziranje podataka.");
        process.exit();
    });
});
function inicializacija(){
    
}