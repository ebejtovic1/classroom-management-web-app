//Ucitavanje podataka iz baze svakih 30 sekundi
$(document).ready(function(){
    pozoviUcitavanje();
    setInterval(pozoviUcitavanje, 30000);
})

function pozoviUcitavanje(){
    //console.log("test");
    Pozivi.ucitajLokacijuOsoblja(document.getElementById("tabelaOsoblja"));
}