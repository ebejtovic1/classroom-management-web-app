//import {Kalendar} from "./kalendar.js";
//import {Pozivi} from "./pozivi.js";


//Spirala 3

//let pozivi = Pozivi;

//let kalendar = Kalendar;
//const db = require("../db.js");
Pozivi.ucitajZauzecasaServera(Kalendar.ucitajPodatke);

//Spirala 4
Pozivi.ucitajOsoblje(document.getElementById("selectOsoblja"));

//Stare spirale

window.addEventListener("resize", setDayOrientation);

pocetak.addEventListener("input", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});

kraj.addEventListener("input", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});

sala.addEventListener("change", event =>{
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    osvjezi(event.target.parentElement.parentElement.children[1], sala, pocetak, kraj);
});
function setDayOrientation(){
    var dan = document.getElementsByClassName("dan")[0];
    if(dan == null) return;
    var screenSize = window.matchMedia("(max-width: 600px)")
    if(screenSize.matches){
        if(dan.style.gridRow == "auto / auto"){
            dan.style.gridRow = dan.style.gridColumn;
            dan.style.gridColumn = "auto";
        }
    }
    else{
        if(dan.style.gridColumn == "auto / auto"){
            dan.style.gridColumn = dan.style.gridRow;
            dan.style.gridRow = "auto";
        }
    }
}

let daniButtons = document.getElementById("kalendar").children[2].children;
dodajClickListenere();

prethodniButton.addEventListener("click", event =>{
    prethodniMjesec(event.target);
    daniButtons = document.getElementById("kalendar").children[2].children;
    dodajClickListenere();
});

sljedeciButton.addEventListener("click", event =>{
    sljedeciMjesec(event.target);
    daniButtons = document.getElementById("kalendar").children[2].children;
    dodajClickListenere();
});

function prethodniMjesec(buttonRef){
    var mjesec = dajBrojTrenutnogMjeseca(buttonRef.parentElement);
    if(mjesec == 0) return;
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    Kalendar.iscrtajKalendar(buttonRef.parentElement, (mjesec !=0 ? mjesec-1 : 11));
    osvjezi(buttonRef.parentElement, sala, pocetak, kraj);
}
function sljedeciMjesec(buttonRef){
    var mjesec = dajBrojTrenutnogMjeseca(buttonRef.parentElement);
    if(mjesec == 11) return;
    var sala = document.getElementById("sala").value;
    var pocetak = document.getElementById("pocetak").value;
    var kraj = document.getElementById("kraj").value;
    Kalendar.iscrtajKalendar(buttonRef.parentElement, (mjesec !=11 ? mjesec+1 : 0));
    osvjezi(buttonRef.parentElement, sala, pocetak, kraj);
}

function dodajClickListenere(){
    daniButtons = document.getElementById("kalendar").children[2].children;
    for(var i = 0; i < daniButtons.length; i++){
        daniButtons[i].addEventListener("click", event=>{
            rezervisiDan(event.target.parentElement);
        })
    }
}

function rezervisiDan(dan){
    let kalRef = document.getElementById("kalendar");
    let sala = document.getElementById("sala").value;
    let pocetak = document.getElementById("pocetak").value;
    let kraj = document.getElementById("kraj").value;
    let predavac = document.getElementById("selectOsoblja").value;
    //rezervacija dana na koji je kliknuto
    var rezervisi = confirm("Da li želite rezervisati ovaj termmin?");
    if(rezervisi == true){
        let check = document.getElementById("periodic").checked;
        let mjesec = dajBrojTrenutnogMjeseca(kalRef);
        /*if(dan.children[1].classList.contains("zauzeta")){
            alert("Nije moguće rezervisati salu "+sala+" za navedeni datum "+dan.children[0].innerHTML+"/"+(mjesec+1)+"/2019 i termin od "+pocetak+" do "+kraj+"!")
            return;
        }*/
        Pozivi.rezervisiTermin(dan.children[0].innerHTML, mjesec,check, pocetak, kraj, sala, predavac);
    }
    else{
        
    }
    //osvjezi(kalRef, sala, pocetak, kraj);
}