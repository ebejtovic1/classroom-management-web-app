const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19", "root", "root", {host:"127.0.0.1",dialect:"mysql",logging:false});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

//import dio
db.osoblje = sequelize.import(__dirname+"/Osoblje.js");
db.rezervacija = sequelize.import(__dirname+"/Rezervacija.js");
db.termin = sequelize.import(__dirname+"/Termin.js");
db.sala = sequelize.import(__dirname+"/Sala.js");

//Relacije tabela
db.termin.hasMany(db.rezervacija, {foreignKey: "termin", as:"terminRezervacije"});
db.rezervacija.belongsTo(db.termin, {foreignKey:"termin"});

db.sala.hasMany(db.rezervacija, {foreignKey:"sala", as:"salaRezervacije"});
db.rezervacija.belongsTo(db.sala, {foreignKey: "sala"});

db.osoblje.hasMany(db.rezervacija, {foreignKey: "osoba", as:"osobljeRezervacije"});
db.rezervacija.belongsTo(db.osoblje, {foreignKey: "osoba"});

db.osoblje.hasMany(db.sala, {foreignKey:"zaduzenaOsoba", as:"zaduzenaOsobaRezervacije"});
db.sala.belongsTo(db.osoblje, {foreignKey: "zaduzenaOsoba"});

db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
    });
});

db.syncAgain = function (){
    return db.sequelize.sync({force:true}).then(function(){
        inicializacija().then(function(){
            console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        });
    });
}

module.exports = db;

function inicializacija(){
    var listaOsobljePromisea = [];
    var listaSalaPromisea = [];
    var listaTerminPromisea = [];
    var listaRezervacijaPromisea = [];
    var osoba1;
    var osoba2;
    var osoba3;
    var termin1;
    var termin2;
    var sala1;
    var sala2;
    var rezervacija1;
    var rezervacija2;

    return new Promise(function(resolve, reject){
        listaRezervacijaPromisea.push(db.rezervacija.create({}));
        listaRezervacijaPromisea.push(db.rezervacija.create({}));

        Promise.all(listaRezervacijaPromisea).then(function(k){
            rezervacija1 = k.find(function(a){ return a.id === 1;});
            rezervacija2 = k.find(function(a){ return a.id === 2;});

            //Kreiranje pocetnih sala
            listaSalaPromisea.push(
                //Treba 1-11
                db.sala.create({naziv:"1-11"}).then(function(k){
                    k.setSalaRezervacije([rezervacija1,rezervacija2]);
                    return new Promise(function(resolve,reject){resolve(k);});
                })
            );
            listaSalaPromisea.push(db.sala.create({naziv:"1-15"}));

            Promise.all(listaSalaPromisea).then(function(k){
                sala1 = k.find(function(a){ return a.id === 1;});
                sala2 = k.find(function(a){ return a.id === 2;});

                //Kreiranje pocetnih termina
                listaTerminPromisea.push(
                    db.termin.create({redovni:false, dan:null, datum:"01.01.2020", semestar: null, pocetak:"12:00", kraj:"13:00"}).then(function(k){
                        k.setTerminRezervacije([rezervacija1]);
                        return new Promise(function(resolve,reject){resolve(k);});
                    })
                );
                listaTerminPromisea.push(
                    db.termin.create({redovni:true, dan:0, datum:null, semestar: "zimski", pocetak:"13:00", kraj:"14:00"}).then(function(k){
                        k.setTerminRezervacije([rezervacija2]);
                        return new Promise(function(resolve,reject){resolve(k);});
                    })
                );

                Promise.all(listaTerminPromisea).then(function(k){
                    termin1 = k.find(function(a){ return a.id === 1; }); //nek se nadje :D
                    termin2 = k.find(function(a){ return a.id === 2; });

                    //Kreiranje pocetnog osoblja
                    listaOsobljePromisea.push(
                        db.osoblje.create({ime:"Neko", prezime:"Nekić", uloga:"profesor"}).then(function(k){
                            return k.setOsobljeRezervacije([rezervacija1]).then(function(){
                                return k.setZaduzenaOsobaRezervacije([sala1]).then(function(){
                                    return new Promise(function(resolve,reject){resolve(k);});
                                    });
                            });
                        })
                    );
                    listaOsobljePromisea.push(
                        db.osoblje.create({ime:"Drugi", prezime:"Neko", uloga:"asistent"}).then(function(k){
                            return k.setZaduzenaOsobaRezervacije([sala2]).then(function(){
                                return new Promise(function(resolve,reject){resolve(k);});
                                });
                        })
                    );
                    listaOsobljePromisea.push(
                        db.osoblje.create({ime:"Test", prezime:"Test", uloga:"asistent"}).then(function(k){
                            return k.setOsobljeRezervacije([rezervacija2]).then(function(){
                                return new Promise(function(resolve,reject){resolve(k);});
                                });
                        })
                    );

                    Promise.all(listaOsobljePromisea).then(function(b){resolve(b);}).catch(function(err){console.log("Osoblje greska: "+err);});
                }).catch(function(err){console.log("Termin greska: "+err);});
            }).catch(function(err){console.log("Sala greska: "+err);});
        }).catch(function(err){console.log("Rezervacija greska: "+err);});
    });
}
