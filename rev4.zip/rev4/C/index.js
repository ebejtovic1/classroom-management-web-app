const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const db = require("./public/db.js");
const app = express();

let ljetniSemestar = [1,2,3,4,5];
let zimskiSemestar = [0,9,10,11];

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));
app.use(express.static(__dirname+'/public'));
app.get("/", function(req,res){
    res.sendFile("/public/html/pocetna.html", {root : __dirname});
});
app.get("/pocetna.html", function(req,res){
    res.sendFile("/public/html/pocetna.html", {root : __dirname});
});
app.get("/sale.html", function(req,res){
    res.sendFile("/public/html/sale.html", {root : __dirname});
});
app.get("/unos.html", function(req,res){
    res.sendFile("/public/html/unos.html", {root : __dirname});
});
app.get("/rezervacija.html", function(req,res){
    res.sendFile("/public/html/rezervacija.html", {root : __dirname});
});

//Za spiralu 4 GET nove stranice
app.get("/osobe.html", function(req,res){
    res.sendFile("/public/html/osobe.html", {root : __dirname});
});

app.post("/json/zauzeca.json", function(req, res){
    let obj = req.body;

    //obj je novo zauzece, zavisno od toga koje je vrste dodaje se na tu listu i sve se ponovo upisuje u json
    let data = JSON.parse(fs.readFileSync(__dirname+"/public/json/zauzeca.json"));
    if(obj["dan"] != "" && obj["dan"] != null){
        obj["dan"] = parseInt(obj["dan"]);
        for(var i = 0; i <data.periodicna.length; i++){
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                if(podaci.dan == obj.dan){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            }            
        }

        data.periodicna.push(obj);
    }
    else{
        for(var i = 0; i <data.periodicna.length; i++){
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                let danSedmice = dajDan(parseDate(obj.datum));
                if(podaci.dan == danSedmice){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            }            
        }
        for(var i = 0; i <data.vanredna.length; i++){
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                if(podaci.datum == obj.datum){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            } 
        }
        data.vanredna.push(obj);
    }
    fs.writeFileSync(__dirname+"/public/json/zauzeca.json", JSON.stringify(data));
    res.status(200);
    res.send("OK");
})
app.get("/slike/", function(req,res){
    var dirList = [];
    var broj = parseInt(req.query["broj"]);
    //ucitavanje liste slike i prosljedivanje one po redu koja je sljedeca ili prazan string
    fs.readdir(__dirname+"/public/slike", function(err, items){
        dirList = items;
        if(items.length > broj){
            res.send(items[broj]);
        }
        else{
            res.send("");
        }
    });
});

//Za spiralu 4

app.get("/osoblje", function(req, res){
    var lista = [];
    db.osoblje.findAll().then(function(podaci){
        if(podaci.length != 0){
            podaci.forEach(element => {
                var instanca = {};
                instanca.ime = element.ime;
                instanca.prezime = element.prezime;
                instanca.uloga = element.uloga;
                lista.push(instanca);
            })
            res.status(200);
            res.send(lista);
        }
        else{
            res.status(400).send({message:"Nema podataka."});
        }
    });
    
});

app.get("/sveRezervacije", function(req, res){
    var data = {};
    var listaPeriodicna = [];
    var listaVanredna = [];

    db.rezervacija.findAll({
        include: [{model: db.termin}, {model: db.sala}, {model: db.osoblje}]
    }).then(function(podaci){
        if(podaci.length != 0){
            podaci.forEach(element => {
                var objekat = {};
                objekat.pocetak = element.Termin.pocetak.substring(0,5);
                objekat.kraj = element.Termin.kraj.substring(0,5);
                objekat.naziv = element.Sala.naziv;
                objekat.predavac = element.Osoblje.ime+" "+element.Osoblje.prezime;
                if(element.Termin.redovni == true){
                    objekat.dan = element.Termin.dan;
                    objekat.semestar = element.Termin.semestar;
                    listaPeriodicna.push(objekat);
                }
                else{
                    objekat.datum = element.Termin.datum;
                    listaVanredna.push(objekat);
                }
            })

            data.periodicna = listaPeriodicna;
            data.vanredna = listaVanredna;
            res.status(200);
            res.send(data);
        }
        else{
            res.status(400).send({message:"Nema podataka."});
        }
    });
    
});

app.post("/rezervisi", function(req, res){
    let object = req.body;
    //let object = req;
    let indeksSale;
    //Nadi indeks sale koja se pokusava zauzet ili kreiraj ako ne postoji u bazi
    db.sala.findOrCreate({where:{naziv: object.naziv}, include: [{model: db.rezervacija, as: "salaRezervacije", include: [{model:db.termin}, {model: db.osoblje}]}]}).then(function(sala){
        sala = sala[0];
        let salaId = sala.id;
        let imePrezime = object.predavac.split(" ");
        //if ako postoje rezervacije za tu salu - else ako ne postoji nijedna rezervacija za tu salu
        if(sala.salaRezervacije){
            //provjeriti da li je zauzet taj termin
            let zauzeto = false;

            for(let rezervacija of sala.salaRezervacije){
                let pocetakTermina = parseTime(rezervacija.Termin.pocetak);
                let krajTermina = parseTime(rezervacija.Termin.kraj);
                let pocetakPokusaja = parseTime(object.pocetak);
                let krajPokusaja = parseTime(object.kraj);

                //ako se termin pokusaja NE nalazi u potpunosti prije ili poslije termina koji provjeravamo - sala rezervisana u tom terminu - odbij rezervaciju
                if(!((pocetakTermina <= pocetakPokusaja && krajTermina <= pocetakPokusaja) || (krajPokusaja <= pocetakTermina && krajPokusaja <= krajTermina))){
                    if(rezervacija.Termin.redovni){
                        if(object.redovno){
                            if(rezervacija.Termin.dan == object.dan) zauzeto = true;
                        }
                        else{

                            if(rezervacija.Termin.dan == dajDan(parseDate(object.datum))) zauzeto = true;
                        }
                    }
                    else{
                        if(object.redovno){
                            if(dajDan(parseDate(rezervacija.Termin.datum)) == object.dan) zauzeto = true;
                        }
                        else{
                            if(rezervacija.Termin.datum == object.datum) zauzeto = true;
                        }
                    }
                }
            }
            //ako se barem jedna od rezervacija preklapa sa terminom koji pokusavamo zauzeti, nemoguce je zauzeti, vrati gresku
            if(zauzeto){
                res.status(400);
                //res.send("Error - termin zauzet!");
            }
            else{
                //kreiranje rezervacije ako termin nije zauzet
                //if redovno zauzece, else vanredno
                if(object.redovno){
                    return db.osoblje.findOrCreate({where: {ime:imePrezime[0], prezime: imePrezime[1]}}).then(function(osoba){
                        osoba = osoba[0];
                        let osobaId = osoba.id;
                        return db.termin.create({redovni:true, dan: object.dan, semestar: object.semestar, pocetak: object.pocetak, kraj: object.kraj}).then(function(termin){
                            return db.rezervacija.create({termin:termin.id, sala: salaId, osoba: osobaId}).then(function(k){
                                return new Promise(function(resolve, reject){ resolve(k);});
                            });
                            
                        });
                    });                
                }
                else{
                    return db.osoblje.findOrCreate({where: {ime:imePrezime[0], prezime: imePrezime[1]}}).then(function(osoba){
                        osoba = osoba[0];
                        let osobaId = osoba.id;
                        return db.termin.create({redovni:false, datum: object.datum, pocetak: object.pocetak, kraj: object.kraj}).then(function(termin){
                            return db.rezervacija.create({termin:termin.id, sala: salaId, osoba: osobaId}).then(function(k){
                                return new Promise(function(resolve, reject){ resolve(k);});
                            });
                            
                        });
                    }); 
                }
            }

        }
        else{
            //ne postoje rezervacije, moze se kreirati rezervacija
            
            //if redovno zauzece, else vanredno
            if(object.redovno){
                return db.osoblje.findOrCreate({where: {ime:imePrezime[0], prezime: imePrezime[1]}}).then(function(osoba){
                    osoba = osoba[0];
                    let osobaId = osoba.id;
                    return db.termin.create({redovni:true, dan: object.dan, semestar: object.semestar, pocetak: object.pocetak, kraj: object.kraj}).then(function(termin){
                        return db.rezervacija.create({termin:termin.id, sala: salaId, osoba: osobaId}).then(function(k){
                            return new Promise(function(resolve, reject){ resolve(k);});
                        });
                        
                    });
                });                
            }
            else{
                return db.osoblje.findOrCreate({where: {ime:imePrezime[0], prezime: imePrezime[1]}}).then(function(osoba){
                    osoba = osoba[0];
                    let osobaId = osoba.id;
                    return db.termin.create({redovni:false, datum: object.datum, pocetak: object.pocetak, kraj: object.kraj}).then(function(termin){
                        return db.rezervacija.create({termin:termin.id, sala: salaId, osoba: osobaId}).then(function(k){
                            return new Promise(function(resolve, reject){ resolve(k);});
                        });
                        
                    });
                }); 
            }
        }
    }).then(function(result){
        res.send(result);
    });
    
    
});

app.get("/lokacijaOsoblja", function(req, res){
    let datum = new Date(Date.now());
    let dan = dajDan(datum);
    let datumString = parseDatetoString(datum);
    let trenutnoVrijeme = getComparableTime(datum);
    let lista = [];
    
   db.osoblje.findAll({include: [{model: db.rezervacija, as: "osobljeRezervacije", include: [{model:db.termin}, {model: db.sala}]}]}).then(function(podaci){
        
        //Nema potrebe da se izvrsava sinhrono, bitan je rezultat kad svi zavrse
        const forLoop = async (osobe)=>{
            for(let element of osobe){
                //Default lokacija ako ne postoji rezervacija
                let lokacijaOsobe = {};
                lokacijaOsobe.osoba = element.ime+" "+element.prezime;
                lokacijaOsobe.sala = "Kancelarija";

               if(element.osobljeRezervacije.length != 0){
                    for(let a of element.osobljeRezervacije){
                        //Izdvoji elemente koji odgovaraju danu
                        if((a.Termin.dan == dan &&  odgovarajuciSemestar(a.Termin.semestar, datum.getMonth())|| a.Termin.datum == datumString)){
                            let pocetak = parseTime(a.Termin.pocetak);
                            let kraj = parseTime(a.Termin.kraj);

                            //izdvoji elemente koji ukljucuju vrijeme
                            if(pocetak <= trenutnoVrijeme && kraj >= trenutnoVrijeme){
                                lokacijaOsobe.sala = a.Sala.naziv;
                            }
                        }
                    }
                }
                lista.push(lokacijaOsobe);
            }
                
        };

        forLoop(podaci).then(function(result){
            res.status(200);
            res.send(lista);
        });
   });
    
});

module.exports = app;

app.listen(8080);


//Pomocne funkcije

function parseDate(string){
    var regex = /^(\d{1,2}).(\d{1,2}).(\d{4})/;
    var items = string.match(regex);
    let datum  = new Date(parseInt(items[3]), parseInt(items[2]-1), parseInt(items[1]),1,0);
    return datum;
}

function parseDatetoString(datum){
    var string = "";
    string += datum.getDate();
    string += "."+(datum.getMonth()+1);
    string += "."+(datum.getFullYear());
    return string;
}
function dajDan(datum){
    let danSedmice;
    (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
    return danSedmice;
}
function parseTime(string){
    var regex = /^(\d{1,2}):(\d{1,2})/;
    var items = string.match(regex);
    let datum = new Date(2019,1,1,items[1], items[2]);
    return datum;
}
function getComparableTime(datum){
    let newDate = new Date(2019,1,1, datum.getHours(), datum.getMinutes());
    return newDate;
}

function odgovarajuciSemestar(semestar, mjesec){
    if(semestar == "ljetni"){
        if(ljetniSemestar.includes(mjesec)){
            return true;
        }
    }
    if(semestar == "zimski"){
        if(zimskiSemestar.includes(mjesec)){
            return true;
        }
    }
    return false;
}