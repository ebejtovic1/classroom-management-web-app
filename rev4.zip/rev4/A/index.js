const express = require('express')
const app = express()
const port = 8080
const bodyParser = require('body-parser')
const fs = require('fs')
const path = require('path')
const db = require(__dirname+'/modeli/db.js');


//db.sequelize.sync({force:true});

var bazaSlika = ['/slike/1.jpg', '/slike/2.jpg', '/slike/3.jpg', '/slike/4.jpg', '/slike/5.jpg', '/slike/6.jpg', '/slike/7.jpg', '/slike/8.jpg']

app.get('/', (req, res) => res.redirect('pocetna.html'))

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/podaciZauzeca', function (req, res) {
  res.sendFile(path.join(__dirname, './', 'zauzeca.json'));
})

app.get('/osoblje', function (req, res) {
	
	var odgovor;
	
	db.osoblje.findAll({
	  raw : true 
	}).then(
		function(resSet) {			
            odgovor = resSet;
			res.send(odgovor);
		}
	);
		
})

app.get('/sale', function (req, res) {
	
	var odgovor;
	
	db.sala.findAll({
	  raw : true 
	}).then(
		function(resSet) {			
            odgovor = resSet;
			res.send(odgovor);
		}
	);
		
})

/*
var periodicnaZauzecaData = [ { "dan":1, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }, 
							  { "dan":3, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							  { "dan":4, "semestar":"ljetni", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }] ;
var vanrednaZauzecaData = [ { "datum":"15.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"17.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"26.5.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"25.3.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac"}]; 
*/

function getPodaci() {
	
	db.rezervacija.findAll({
	  raw : true,
	  include : [{model: db.osoblje, as: 'osobaRezervacija'}, {model: db.termin, as: 'terminRezervacija'}, {model: db.sala, as: 'salaRezervacija'} ]
	}).then(
		function(resSet) {	
				return resSet;
        }
	);
	
}

app.get('/podaciZauzecaBaza', function (req, res) {
	
	db.rezervacija.findAll({
	  raw : true,
	  include : [{model: db.osoblje, as: 'osobaRezervacija'}, {model: db.termin, as: 'terminRezervacija'}, {model: db.sala, as: 'salaRezervacija'} ]
	}).then(
		function(resSet) {	
				res.send(resSet);
        }
	);

})

app.get('/podaciZauzecaBaza1', async function (req, res) {
	
	let data = await db.rezervacija.findAll({
	  raw : true,
	  include : [{model: db.osoblje, as: 'osobaRezervacija'}, {model: db.termin, as: 'terminRezervacija'}, {model: db.sala, as: 'salaRezervacija'} ]
	});
	
	res.send(data);
})


app.get('/naredneSlike', function (req, res) {
  
  //parseInt, parseFloat ili Number
  let brojStranice = parseInt(req.query.brojStranice);
  let ukupno = 2;
  let rb1 = brojStranice * 3;
  let rb2 = brojStranice * 3 + 1;
  let rb3 = brojStranice * 3 + 2;
  
  res.send(JSON.stringify({stranica: brojStranice, ukupnoStranica: ukupno, slika1: bazaSlika[rb1], slika2:bazaSlika[rb2], slika3:bazaSlika[rb3] }));
})

async function dobaviPodatke(dbData) {
	let zauzecaJson = await db.rezervacija.findAll({
	  raw : true,
	  include : [{model: db.osoblje, as: 'osobaRezervacija'}, {model: db.termin, as: 'terminRezervacija'}, {model: db.sala, as: 'salaRezervacija'} ]
   });

    var periodicnaZauzecaData = [];
	var vanrednaZauzecaData = [];
		
	for(i=0; i<zauzecaJson.length; i++) {	
	
			if(zauzecaJson[i]["terminRezervacija.redovni"]==1) {
				
				var temp = {};
				temp["dan"] = zauzecaJson[i]["terminRezervacija.dan"];
				temp["semestar"] = zauzecaJson[i]["terminRezervacija.semestar"];
				temp["pocetak"] = zauzecaJson[i]["terminRezervacija.pocetak"];
				temp["kraj"] = zauzecaJson[i]["terminRezervacija.kraj"];
				temp["naziv"] = zauzecaJson[i]["salaRezervacija.naziv"];
				temp["predavac"] = zauzecaJson[i]["osobaRezervacija.ime"] + " " + zauzecaJson[i]["osobaRezervacija.prezime"];
				
				periodicnaZauzecaData.push(temp);
				console.log(temp);
			}
			
			if(zauzecaJson[i]["terminRezervacija.redovni"]==0) {
				
				var temp = {};
				temp["datum"] = zauzecaJson[i]["terminRezervacija.datum"];
				temp["pocetak"] = zauzecaJson[i]["terminRezervacija.pocetak"];
				temp["kraj"] = zauzecaJson[i]["terminRezervacija.kraj"];
				temp["naziv"] = zauzecaJson[i]["salaRezervacija.naziv"];
				temp["predavac"] = zauzecaJson[i]["osobaRezervacija.ime"] + " " + zauzecaJson[i]["osobaRezervacija.prezime"];
				
				vanrednaZauzecaData.push(temp);
				console.log(temp);
			}
	}
	
	dbData.periodicna = periodicnaZauzecaData;
	dbData.vanredna = vanrednaZauzecaData;
	console.log("PERIODICNA *****");
	console.log(dbData.periodicna);
	console.log("VANREDNA *****");
	console.log(dbData.vanredna);
	
}

app.get('/osobeSale', async function (req, res) {
	
	
	var odgovor = [];
	
	var datumString = "";
	var datumStringLZ = "";
		
	var datumTrenutni = new Date();
	
	var danTrenutni = datumTrenutni.getDate();
	var danTrenutniLZ = "";
	
	var mjesecTrenutni = datumTrenutni.getMonth();
	var mjesecTrenutniLZ = "";
	var godinaTrenutna = datumTrenutni.getFullYear();
	
	var pozicijaDana = 0;
	var danSedmica = datumTrenutni.toString().substring(0, 3);
	if (danSedmica == "Mon") pozicijaDana = 0;
	if (danSedmica == "Tue") pozicijaDana = 1;
	if (danSedmica == "Wed") pozicijaDana = 2;
	if (danSedmica == "Thu") pozicijaDana = 3;
	if (danSedmica == "Fri") pozicijaDana = 4;
	if (danSedmica == "Sat") pozicijaDana = 5;
	if (danSedmica == "Sun") pozicijaDana = 6;
	
	
	var semestarPar = "";
	if ( (mjesecTrenutni) == 9 || (mjesecTrenutni) == 10 || (mjesecTrenutni) == 11 || (mjesecTrenutni ) == 0 ) {
	  semestarPar = "zimski";
	}  
  
	if ( (mjesecTrenutni ) == 1 || (mjesecTrenutni) == 2 || (mjesecTrenutni) == 3 || (mjesecTrenutni) == 4 || (mjesecTrenutni) == 5 ){
	  semestarPar = "ljetni";
	}
	
	if (danTrenutni.toString().length == 1) {danTrenutniLZ += "0" + danTrenutni.toString()} else {danTrenutniLZ = danTrenutni};
	if (mjesecTrenutni.toString().length == 1) {mjesecTrenutniLZ += "0".concat(mjesecTrenutni+1) } else {mjesecTrenutniLZ = mjesecTrenutni+1};
	
	datumString = danTrenutni + "." + (mjesecTrenutni+1) + "." + godinaTrenutna;
	datumStringLZ = danTrenutniLZ + "." + mjesecTrenutniLZ + "." + godinaTrenutna;
	
	console.log(danTrenutni);
	console.log(mjesecTrenutni+1);
	console.log(godinaTrenutna);
	console.log(pozicijaDana);
	console.log(semestarPar);
	
	console.log(datumString);
	console.log(datumStringLZ);
	
	//dobavi sve osobe
	let osobe = await db.osoblje.findAll({
	  raw : true,
    });
	
	let zauzeca = await db.rezervacija.findAll({
	  raw : true,
	  include : [{model: db.osoblje, as: 'osobaRezervacija'}, {model: db.termin, as: 'terminRezervacija'}, {model: db.sala, as: 'salaRezervacija'} ]
   });
   
   
	osobe.forEach(osoba => {
        console.log(osoba.id + " " +  osoba.ime);
		var uslov1 = false;
		var uslov2 = false;
		var osobaPodaci = osoba.ime + " " + osoba.prezime;
		var sala = "kancelarija";
		
		zauzeca.forEach(zauzece => {
			
			//console.log(zauzece["terminRezervacija.datum"] + " uslov1-a " + datumStringLZ );
			//console.log(zauzece["osobaRezervacija.id"] + " uslov1-a " + osoba.id );
		    //provjeriti datum ili (dan + semestar)
			if ( (zauzece["terminRezervacija.datum"] == datumString || zauzece["terminRezervacija.datum"] == datumStringLZ) && zauzece["osobaRezervacija.id"] == osoba.id ) {
				uslov1 = true;
				//console.log("uslov1-a!");
				}
			
			
			console.log(zauzece["terminRezervacija.semestar"] + " uslov1-a " + semestarPar );
			console.log(zauzece["terminRezervacija.dan"] + " uslov1-a " + pozicijaDana );
			console.log(zauzece["osobaRezervacija.id"] + " uslov1-a " + osoba.id );
			if ( zauzece["terminRezervacija.semestar"] == semestarPar && zauzece["terminRezervacija.dan"] == pozicijaDana && zauzece["osobaRezervacija.id"] == osoba.id ) {
				uslov1 = true;
				console.log("uslov1-b!")
				}
			
			// provjeriti da li vrijeme odgovara
			if (uslov1) {
				console.log("USLOV1 - " + osobaPodaci);
				var today = new Date();
				var vrijemeTrenutno = "01/01/2011 " + today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
				var vrijemePocetak = "01/01/2011 " + zauzece["terminRezervacija.pocetak"];
				var vrijemeKraj = "01/01/2011 " + zauzece["terminRezervacija.kraj"];
				
				if ( (Date.parse(vrijemePocetak) < Date.parse(vrijemeTrenutno)) && ( Date.parse(vrijemeTrenutno) < Date.parse(vrijemeKraj) ) ) {
				//if ( (zauzece["terminRezervacija.pocetak"] < vrijemeTrenutno ) && (vrijemeTrenutno < zauzece["terminRezervacija.kraj"] ) ) {
					uslov2=true;
					console.log("uslov2");
					}
			}
			
			if (uslov1 && uslov2 && sala=="kancelarija") { 
				sala = zauzece["salaRezervacija.naziv"]; 
			};
			
		});
		odgovor += "<br> Osoba: " + osobaPodaci + " se nalazi u sali: " + sala;
    });
	

	res.send(odgovor);
})

app.get('/rezervacija', async function (req, res) {
  
  let salaPar = req.query.sala;
  let periodicnaParametar = req.query.periodicna;
  let periodicna = false;
  if (periodicnaParametar == "true") periodicna = true;
  let pocetakPar = req.query.pocetak;
  let krajPar = req.query.kraj;
  let dan = req.query.dan;
  let mjesec = req.query.mjesec;
  let godina = req.query.godina;
  let osobaPar = req.query.osoba;
  let salaNaziv = req.query.salaNaziv;
  
  var odgovor = {};
  
  var osobaPreklapanje = "";
  
  var datumString = dan + "." + mjesec + "." +  godina;
  
  var datum = new Date(godina, mjesec - 1, dan);
  var danSedmica = datum.toString().substring(0, 3);
  
  var pozicijaDana = 0;
  
  if (danSedmica == "Mon") pozicijaDana = 0;
  if (danSedmica == "Tue") pozicijaDana = 1;
  if (danSedmica == "Wed") pozicijaDana = 2;
  if (danSedmica == "Thu") pozicijaDana = 3;
  if (danSedmica == "Fri") pozicijaDana = 4;
  if (danSedmica == "Sat") pozicijaDana = 5;
  if (danSedmica == "Sun") pozicijaDana = 6;
  
  var semestarPar = "";
  if ( (mjesec - 1) == 9 || (mjesec - 1) == 10 || (mjesec - 1) == 11 || (mjesec - 1) == 0 ) {
	  semestarPar = "zimski";
	}  
  
  if ( (mjesec - 1) == 1 || (mjesec - 1) == 2 || (mjesec - 1) == 3 || (mjesec - 1) == 4 || (mjesec - 1) == 5 ){
	  semestarPar = "ljetni";
	}
  
	var dbData = {periodicna : "" , vanredna : ""};
	await dobaviPodatke(dbData);
  	
  // provjera da li je moguce rezervisati
  // ako je periodicna samo jedno zauzece ako postoji nije moguce
  // ako nije periodicna bitno je da je dan slobodan
  var periodicnaNiz = dbData.periodicna;
  var vanrednaNiz = dbData.vanredna;
  var moguceRezervisati = true;
  var pogresanMjesec = false;
  
  if (periodicna) {	 

	if ( ( mjesec == 6) || (mjesec == 7) || (mjesec == 8) ) {
		moguceRezervisati = false;
		pogresanMjesec = true;
	}
  
	for(i=0; i<periodicnaNiz.length; i++) {
		if (pogresanMjesec) break;
		if ( periodicnaNiz[i].dan === pozicijaDana && periodicnaNiz[i].semestar === semestarPar && periodicnaNiz[i].naziv === salaNaziv
				&& (
						( 
							( Date.parse("01/01/2011 " + pocetakPar) >= Date.parse("01/01/2011 " + periodicnaNiz[i]["pocetak"]) ) 
							&& 
							( Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + periodicnaNiz[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + periodicnaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) <= Date.parse("01/01/2011 " + periodicnaNiz[i]["kraj"]) )
						)
						|| 
						( 
							(Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + periodicnaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + periodicnaNiz[i]["kraj"]) )
						)
					)
			) {
			moguceRezervisati = false;
			osobaPreklapanje = periodicnaNiz[i].predavac;
			break;
		}
	}

	for(i=0; i<vanrednaNiz.length; i++) {
		if (pogresanMjesec) break;
		// provjeriti koji je dan vanredno zauzeze tj naci mu poziciju
		var datumKomponente = vanrednaNiz[i].datum.split(".");
		
		var vanrednaDate = new Date(datumKomponente[2], datumKomponente[1] - 1, datumKomponente[0]);
		var vanrednaDan = vanrednaDate.toString().substring(0, 3);
		var vanrednaPozicijaDana = 0;
			
		if (vanrednaDan == "Mon") vanrednaPozicijaDana = 0;
		if (vanrednaDan == "Tue") vanrednaPozicijaDana = 1;
		if (vanrednaDan == "Wed") vanrednaPozicijaDana = 2;
		if (vanrednaDan == "Thu") vanrednaPozicijaDana = 3;
		if (vanrednaDan == "Fri") vanrednaPozicijaDana = 4;
		if (vanrednaDan == "Sat") vanrednaPozicijaDana = 5;
		if (vanrednaDan == "Sun") vanrednaPozicijaDana = 6;
		
		if (pozicijaDana == vanrednaPozicijaDana
			&& salaNaziv == vanrednaNiz[i].naziv
			 && (
						( 
							( Date.parse("01/01/2011 " + pocetakPar) >= Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) ) 
							&& 
							( Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) <= Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
					)
		) {
			moguceRezervisati = false;
			osobaPreklapanje = vanrednaNiz[i].predavac;
			break;
		}
	}
	
  } else { //vanredna
	for(i=0; i<vanrednaNiz.length; i++) {
		if (vanrednaNiz[i].datum === datumString
			&& salaNaziv == vanrednaNiz[i].naziv
			&& (
						( 
							( Date.parse("01/01/2011 " + pocetakPar) >= Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) ) 
							&& 
							( Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) <= Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + pocetakPar) < Date.parse("01/01/2011 " + vanrednaNiz[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + krajPar) > Date.parse("01/01/2011 " + vanrednaNiz[i]["kraj"]) )
						)
						
					)
			) {
			moguceRezervisati = false;
			osobaPreklapanje = vanrednaNiz[i].predavac;
			break;		
		}
	}
  }
  
  //redovni - true
  if (moguceRezervisati && periodicna) {
	  
	  var termin = await db.termin.create({redovni:true, dan:pozicijaDana, semestar:semestarPar, pocetak:pocetakPar, kraj:krajPar});
	  var termin_id = termin.id;
	  await db.rezervacija.create({termin:termin_id, sala:salaPar, osoba:osobaPar});
	  
  }
  
  //redovni - false
  if (moguceRezervisati && !periodicna) {
	  
	  var termin = await db.termin.create({redovni:false, datum:datumString, pocetak:pocetakPar, kraj:krajPar});
	  var termin_id = termin.id;
	  await db.rezervacija.create({termin:termin_id, sala:salaPar, osoba:osobaPar});
	  
  }
  
  if(moguceRezervisati) { 
	odgovor.greska = "OK";
		
	var dbData = {periodicna : "" , vanredna : ""};
	await dobaviPodatke(dbData);
	
	odgovor.periodicnaZauzeca = dbData.periodicna;
	odgovor.vanrednaZauzeca = dbData.vanredna;
	
  };
  
  if(!moguceRezervisati) {
	odgovor.greska = "Nije moguce rezervisati salu " + salaNaziv + " za navedeni datum " + dan + "/" + mjesec + "/" + godina + " i termin od " + pocetakPar + " do " + krajPar + "!"
	+ "Salu je zauzela osoba: " + osobaPreklapanje + "!";
	
	if (pogresanMjesec) odgovor.greska = "Izabrani mjesec ne pripada ni jednom semestru."
	  
	var dbData = {periodicna : "" , vanredna : ""};
	await dobaviPodatke(dbData);
	
	odgovor.periodicnaZauzeca = dbData.periodicna;
	odgovor.vanrednaZauzeca = dbData.vanredna;
  
  }

  res.send(JSON.stringify(odgovor));
})

app.use(express.static('public'))

app.listen(port, () => console.log(`Aplikacija pokrenuta na portu: ${port}!`))