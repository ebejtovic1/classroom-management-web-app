const Sequelize = require("sequelize");
const sequelize = new Sequelize('mysql://root:root@localhost:3306/dbwt19');
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+"/osoblje.js");
db.sala = sequelize.import(__dirname+"/sala.js");
db.termin = sequelize.import(__dirname+"/termin.js");
db.rezervacija = sequelize.import(__dirname+"/rezervacija.js");

//relacije
db.osoblje.hasOne(db.sala, {foreignKey: 'zaduzenaOsoba'});
db.sala.belongsTo(db.osoblje, {as: 'odgovornaOsoba', foreignKey: 'zaduzenaOsoba'});

db.osoblje.hasMany(db.rezervacija, {foreignKey: 'osoba'});
db.rezervacija.belongsTo(db.osoblje, { as: 'osobaRezervacija', foreignKey: 'osoba'});

db.sala.hasMany(db.rezervacija, {foreignKey: 'sala'});
db.rezervacija.belongsTo(db.sala, { as:'salaRezervacija', foreignKey: 'sala'});

db.termin.hasOne(db.rezervacija, {foreignKey: 'termin'});
db.rezervacija.belongsTo(db.termin, { as:'terminRezervacija', foreignKey: 'termin'});

db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
    });
});


//inicijalizacija
function inicializacija(){
	
	var osobljeListaPromisea=[];
	var salaListaPromisea=[];
	var terminiListaPromisea=[];
	var rezervacijeListaPromisea=[];
	
	return new Promise(function(resolve,reject){
	
		osobljeListaPromisea.push(db.osoblje.create({ime:"Neko", prezime: "Nekic", uloga:"profesor"}));
		osobljeListaPromisea.push(db.osoblje.create({ime:"Drugi", prezime: "Neko", uloga:"asistent"}));
		osobljeListaPromisea.push(db.osoblje.create({ime:"Test", prezime: "Test", uloga:"asistent"}));
		
		Promise.all(osobljeListaPromisea).then(function(osoblje){
			
			var neko = osoblje.filter(function(a){return a.ime==='Neko'})[0];
			var drugi = osoblje.filter(function(a){return a.ime==='Drugi'})[0];
			var test = osoblje.filter(function(a){return a.ime==='Test'})[0];
				
			salaListaPromisea.push(
				db.sala.create({naziv:"1-11"}).then(function(k){
					return k.setOdgovornaOsoba(neko).then(function(k){
						return new Promise(function(resolve,reject){resolve(k);});
					})
				})
			);
			
			salaListaPromisea.push(
				db.sala.create({naziv:"1-15"}).then(function(h){
					return h.setOdgovornaOsoba(drugi).then(function(h){
						return new Promise(function(resolve,reject){resolve(h);});
					})
				})
			);
			
			Promise.all(salaListaPromisea).then(function(sale){
				
				var salaPrva = sale.filter(function(a){return a.naziv==='1-11'})[0];
				var salaDruga = sale.filter(function(a){return a.naziv==='1-15'})[0];
				
				terminiListaPromisea.push(db.termin.create({redovni:false, datum:"01.01.2020", pocetak:"12:00", kraj:"13:00"}));
				terminiListaPromisea.push(db.termin.create({redovni:true, dan:0, semestar:"zimski", pocetak:"13:00", kraj:"14:00"}));
				
				Promise.all(terminiListaPromisea).then(function(termini){
					var terminPrvi = termini.filter(function(a){return a.pocetak==='12:00'})[0];
					var terminDrugi = termini.filter(function(a){return a.pocetak==='13:00'})[0];
					
					rezervacijeListaPromisea.push(db.rezervacija.create().then(function(b){
							return b.setTerminRezervacija(terminPrvi).then( function(b){
								return b.setSalaRezervacija(salaPrva).then ( function(b){
									return b.setOsobaRezervacija(neko).then ( function(b) {
										return new Promise(function(resolve,reject){resolve(b);});
									})
								})							
							});						
						})
					);
					
					rezervacijeListaPromisea.push(db.rezervacija.create().then(function(b){
							return b.setTerminRezervacija(terminDrugi).then( function(b){
								return b.setSalaRezervacija(salaPrva).then ( function(b){
									return b.setOsobaRezervacija(test).then ( function(b) {
										return new Promise(function(resolve,reject){resolve(b);});
									})
								})							
							});						
						})
					);
					
					Promise.all(rezervacijeListaPromisea).then(function(c){
						resolve(c);
					}).catch(function(err){console.log("Rezervacija greska "+ err);});
					
				}).catch(function(err){console.log("Termini greska: " + err);}); 
									
			}).catch(function(err){console.log("Sale greska: " + err);}); 
			
		}).catch(function(err){console.log("Osoblje greska: " + err);}); 
		
	});
}

module.exports=db;