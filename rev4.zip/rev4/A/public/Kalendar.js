let Kalendar = ( function () {

	var aktivniMjesec = 10;
	var periodicnaZauzeca;
	var vanrednaZauzeca; 
	
	function redniBrojMjesecaImp(naziv) {
		
		if (naziv == "Januar") {
			return 1;
		} else if (naziv == "Februar") {
			return 2;
		} else if (naziv == "Mart") {
			return 3;
		} else if (naziv == "April") {
			return 4;
		} else if (naziv == "Maj") {
			return 5;
		} else if (naziv == "Juni") {
			return 6;
		} else if (naziv == "Juli") {
			return 7;
		} else if (naziv == "August") {
			return 8;
		} else if (naziv == "Septembar") {
			return 9;
		} else if (naziv == "Oktobar") {
			return 10;
		} else if (naziv == "Novembar") {
			return 11;
		} else if (naziv == "Decembar") {
			return 12;
		} else {
			return null;
		}
		
	}
	
	function podesiAktivniMjesecImp(mjesec) {
		aktivniMjesec = mjesec;
	}
		
	function nazivMjeseca(redniBroj) {
		
		if (redniBroj == 0) {
			return "januar";
		} else if (redniBroj == 1) {
			return "februar";
		} else if (redniBroj == 2) {
			return "mart";
		} else if (redniBroj == 3) {
			return "april";
		} else if (redniBroj == 4) {
			return "maj";
		} else if (redniBroj == 5) {
			return "juni";
		} else if (redniBroj == 6) {
			return "juli";
		} else if (redniBroj == 7) {
			return "august";
		} else if (redniBroj == 8) {
			return "septembar";
		} else if (redniBroj == 9) {
			return "oktobar";
		} else if (redniBroj == 10) {
			return "novembar";
		} else if (redniBroj == 11) {
			return "decembar";
		} else {
			return null;
		}
	
	}
		
	function iscrtajKalendarImp(kalendarRef, mjesec) {
		
		var kalendarDjeca = kalendarRef.children;
		if (kalendarDjeca.length > 1) {		
			kalendarDjeca[0].remove();
		} 
		
		kalendarRef.prepend(document.createElement("div"));
		
		var mjesecObj = kalendarRef.children[0];
		mjesecObj.setAttribute("id", nazivMjeseca(mjesec) );
		
		mjesecObj.append(document.createElement("div"));
		var naslovDivObj = mjesecObj.children[0];
		naslovDivObj.setAttribute("class", "mjesecNaslov" );
		
		naslovDivObj.append(document.createElement("h1"));
		var naslovObj = naslovDivObj.children[0];
		naslovObj.innerHTML = nazivMjeseca(mjesec).charAt(0).toUpperCase() + nazivMjeseca(mjesec).slice(1);
		
		mjesecObj.append(document.createElement("div"));
		var daniSedmiceDivObj = mjesecObj.children[1];
		daniSedmiceDivObj.setAttribute("class", "sedmica");
				
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[0];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "PON";
		
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[1];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "UTO";
		
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[2];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "SRI";
		
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[3];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "ČET";
		
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[4];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "PET";

		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[5];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "SUB";
		
		daniSedmiceDivObj.append(document.createElement("div"));
		var danSedmiceObj = daniSedmiceDivObj.children[6];
		danSedmiceObj.setAttribute("class", "dan naslovDan");
		danSedmiceObj.innerHTML = "NED";
		
		var trenutniDatum = new Date();
		var prviDanTemp = new Date (trenutniDatum.getFullYear(), mjesec, 1);
		var prviDan = prviDanTemp.toString().substring(0, 3);
		var brojDana = new Date(trenutniDatum.getFullYear(), mjesec + 1, 0).getDate(); 
		
		var pocetnaPozicija = 0;
		
		if (prviDan == "Mon") pocetnaPozicija = 0;
		if (prviDan == "Tue") pocetnaPozicija = 1;
		if (prviDan == "Wed") pocetnaPozicija = 2;
		if (prviDan == "Thu") pocetnaPozicija = 3;
		if (prviDan == "Fri") pocetnaPozicija = 4;
		if (prviDan == "Sat") pocetnaPozicija = 5;
		if (prviDan == "Sun") pocetnaPozicija = 6;
		
		var brojSedmica = Math.ceil( (pocetnaPozicija + brojDana) / 7 );
		var brojPraznihPozicijaZadnjaSedmica = (brojSedmica * 7) - brojDana - pocetnaPozicija;
		var redniBroj = 0;
		
		
		for (i=0; i<brojSedmica; i++) {
			
			mjesecObj.append(document.createElement("div"));
			var daniSedmiceDivObj = mjesecObj.children[i+2];
			daniSedmiceDivObj.setAttribute("class", "sedmica");
			
		
			for(j=0; j<7; j++ ) {
				
				daniSedmiceDivObj.append(document.createElement("div"));
				var danObj = daniSedmiceDivObj.children[j];
				
				if ( (i == 0) && (j < pocetnaPozicija) ) {
					danObj.setAttribute("class", "dan prazanDan");
				}
				
				if ( (i == 0) && (j >= pocetnaPozicija) ) {
					redniBroj++;
					danObj.setAttribute("class", "dan");
					danObj.append(document.createElement("div"));
					danObj.append(document.createElement("div"));
					
					var redniBrojObj = danObj.children[0];
					redniBrojObj.setAttribute("class", "redniBroj");
					redniBrojObj.innerHTML = redniBroj;
					
					var statusObj = danObj.children[1];
					statusObj.setAttribute("class", "statusDan slobodna");
					
				}
				
				if ( (i > 0) && (i < brojSedmica - 1) ) {
					redniBroj++;
					danObj.setAttribute("class", "dan");
					danObj.append(document.createElement("div"));
					danObj.append(document.createElement("div"));
					
					var redniBrojObj = danObj.children[0];
					redniBrojObj.setAttribute("class", "redniBroj");
					redniBrojObj.innerHTML = redniBroj;
					
					var statusObj = danObj.children[1];
					statusObj.setAttribute("class", "statusDan slobodna");
					
				}
				
				if ( (i == brojSedmica - 1) && (j < 7 - brojPraznihPozicijaZadnjaSedmica) ) {
					redniBroj++;
					danObj.setAttribute("class", "dan");
					danObj.append(document.createElement("div"));
					danObj.append(document.createElement("div"));
					
					var redniBrojObj = danObj.children[0];
					redniBrojObj.setAttribute("class", "redniBroj");
					redniBrojObj.innerHTML = redniBroj;
					
					var statusObj = danObj.children[1];
					statusObj.setAttribute("class", "statusDan slobodna");
				}
				
				if ( (i == brojSedmica - 1) && (j >= 7 - brojPraznihPozicijaZadnjaSedmica) ) {
					danObj.setAttribute("class", "dan prazanDan");
				}
				
			}
		}

	}
	
	function ucitajPodatkeImp(periodicna, vanredna) {
		
		console.log("UCITAJ PODATKE:");
		console.log(periodicna);
		console.log(vanredna);
		
		periodicnaZauzeca = periodicna;
		vanrednaZauzeca = vanredna;
		
		console.log("UCITANI PODACI:");
		console.log(periodicnaZauzeca);
		console.log(vanrednaZauzeca);
		
	}

	function obojiZauzecaImp(kalendarRef, mjesec, sala, pocetak, kraj) {
		
		console.log("UCITANI PODACI ZAUZECA:");
		console.log(periodicnaZauzeca);
		console.log(vanrednaZauzeca);
	
		var kalendar = kalendarRef.children;
		
		var tempMjesec = kalendar[0];
		var daniMjesec = new Array();	

		 
		 var sedmice = tempMjesec.children;
		 
		 var brojPraznihPozicijaPrvaSedmica = 0;
		 var brojPraznihPozicijaZadnjaSedmica = 0;
		 
 
		 for (i=2; i < sedmice.length; i++) {
			
			var daniTemp = sedmice[i].children;
			
			
			for(j=0; j<daniTemp.length; j++) {
				if( (daniTemp[j].className == "dan prazanDan") && (i == 2) ) {
					brojPraznihPozicijaPrvaSedmica++;				
				}
				if( (daniTemp[j].className == "dan prazanDan") && (i != 2) ) {
					brojPraznihPozicijaZadnjaSedmica++;				
				}
				
				
				if( daniTemp[j].className == "dan" ) {
					elementiDana = daniTemp[j].children;						
					elementStatus = elementiDana[1];
					elementStatus.setAttribute("class", "statusDan slobodna");
				}
				
				daniMjesec.push(daniTemp[j]);
			} 
		 }
		 
		  console.log("vanrednaZauzeca.length");
		  console.log(vanrednaZauzeca.length);
		  
		  for(i=0; i<vanrednaZauzeca.length; i++) {
			
			datumKomponente = vanrednaZauzeca[i]["datum"].split(".");
			danTemp = datumKomponente[0];
			mjesecTemp = datumKomponente[1];
			godinaTemp = datumKomponente[2];
									
			if ( ((mjesecTemp - 1) == mjesec) 
				&& (vanrednaZauzeca[i]["naziv"]==sala) 
				&& (
				( 
					( Date.parse("01/01/2011 " + pocetak) >= Date.parse("01/01/2011 " + vanrednaZauzeca[i]["pocetak"]) ) 
					&& 
					( Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + vanrednaZauzeca[i]["kraj"]) )
				)
				||
				( 
					(Date.parse("01/01/2011 " + kraj) > Date.parse("01/01/2011 " + vanrednaZauzeca[i]["pocetak"]) )
					&&
					(Date.parse("01/01/2011 " + kraj) <= Date.parse("01/01/2011 " + vanrednaZauzeca[i]["kraj"]) )
				)
				|| 
				( 
					(Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + vanrednaZauzeca[i]["pocetak"]) )
					&&
					(Date.parse("01/01/2011 " + kraj) > Date.parse("01/01/2011 " + vanrednaZauzeca[i]["kraj"]) )
				)
				) )  {			
				elementiDana = daniMjesec[ brojPraznihPozicijaPrvaSedmica + (danTemp - 1) ].children;			
				elementStatus = elementiDana[1];
				elementStatus.setAttribute("class", "statusDan zauzeta");
			} 
			
		  }
		  

		  
		  for(i=0; i<periodicnaZauzeca.length; i++) {
		  
			   var potrebnoObojiti = false;
			   
			   console.log("PERIODICNA FORMA: " + sala + " NIZ NAZIV: " + periodicnaZauzeca[i]["naziv"]);
			   console.log("POCETAK: " + pocetak + " NIZ: " + periodicnaZauzeca[i]["pocetak"]);
			   console.log("POCETAK: " + kraj + " NIZ: " + periodicnaZauzeca[i]["kraj"]);
			   
			   if ( (periodicnaZauzeca[i]["naziv"] == sala) 
					&& (periodicnaZauzeca[i]["semestar"] == "zimski") 
					&& (mjesec == 9 || mjesec == 10 || mjesec == 11 || mjesec == 0) 
					&& (
						( 
							( Date.parse("01/01/2011 " + pocetak) >= Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) ) 
							&& 
							( Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + kraj) > Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + kraj) <= Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + kraj) >= Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
					)
					) {
					potrebnoObojiti = true;
			   }		   
			   if ( (periodicnaZauzeca[i]["naziv"] == sala) 
				   && (periodicnaZauzeca[i]["semestar"] == "ljetni") 
				   && (mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5) 
				   && (
						( 
							( Date.parse("01/01/2011 " + pocetak) >= Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) ) 
							&& 
							( Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + kraj) > Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + kraj) <= Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
						||
						( 
							(Date.parse("01/01/2011 " + pocetak) < Date.parse("01/01/2011 " + periodicnaZauzeca[i]["pocetak"]) )
							&&
							(Date.parse("01/01/2011 " + kraj) > Date.parse("01/01/2011 " + periodicnaZauzeca[i]["kraj"]) )
						)
					)
				   ) {
					potrebnoObojiti = true;
			   }
			   			   
			   if(potrebnoObojiti) {				   
	
				   var brojDanaMjesec = daniMjesec.length - brojPraznihPozicijaPrvaSedmica - brojPraznihPozicijaZadnjaSedmica;
				   
				   
				   for( j=periodicnaZauzeca[i]["dan"] ; j<brojDanaMjesec + 7; j=j+7) {   
						if (j < brojPraznihPozicijaPrvaSedmica) continue;
						if (j > brojPraznihPozicijaPrvaSedmica + brojDanaMjesec) continue;					
						
						if(j<daniMjesec.length) {
							elementiDana = daniMjesec[j].children;									
							elementStatus = elementiDana[1];						
							if (typeof elementStatus != 'undefined') {
							  elementStatus.setAttribute("class", "statusDan zauzeta");	
							}							
						}
				   }
			   }
		  }	
	}
	
	function inicijalizirajKalendarImp(sala, pocetak, kraj) {
	
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, sala, pocetak, kraj);
	}
	
	function podesiPrikazKalendara() {
		var mjeseci = document.getElementById("kalendar").children;
		for (i=0; i<12; i ++) {
			if (i == aktivniMjesec) {
				mjeseci[i].setAttribute("class","pokazi");
			} else {
				mjeseci[i].setAttribute("class","sakrij");
			}
		}
	}
	
	function vratiAktivniMjesecImp () {
		return aktivniMjesec;
	}
	
	function aktivniMjesecNaprijedImp() {
		if (aktivniMjesec == 11) {
			document.getElementById("btnNaredni").disabled = true;
			document.getElementById("btnPrethodni").disabled = false;
		} else {
			document.getElementById("btnNaredni").disabled = false;
			document.getElementById("btnPrethodni").disabled = false;
			aktivniMjesec = aktivniMjesec + 1;
		}
		
		Kalendar.iscrtajKalendar(document.getElementById("kalendar"), aktivniMjesec);
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, "TEST", "TEST", "TEST");
		
		var elementiDani = document.getElementsByClassName("dan");
		for (var i = 0; i < elementiDani.length; i++) {
			elementiDani[i].addEventListener('click', rezervisi, false);
		}
	}
	
	function aktivniMjesecNazadImp() {
		if (aktivniMjesec == 0) {
			document.getElementById("btnPrethodni").disabled = true;
			document.getElementById("btnNaredni").disabled = false;
		} else {
			document.getElementById("btnPrethodni").disabled = false;
			document.getElementById("btnNaredni").disabled = false;
			aktivniMjesec = aktivniMjesec -1;
		}
		
		Kalendar.iscrtajKalendar(document.getElementById("kalendar"), aktivniMjesec);
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec, "TEST", "TEST", "TEST");
		
		var elementiDani = document.getElementsByClassName("dan");
		for (var i = 0; i < elementiDani.length; i++) {
			elementiDani[i].addEventListener('click', rezervisi, false);
		}
	}
	
	function osvjeziKalendarImp(){
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), aktivniMjesec + 1, "TEST", "TEST", "TEST");
	}
	
	return {
		vratiAktivniMjesec: vratiAktivniMjesecImp,
		aktivniMjesecNaprijed: aktivniMjesecNaprijedImp,
		aktivniMjesecNazad : aktivniMjesecNazadImp,
		obojiZauzeca : obojiZauzecaImp,
		ucitajPodatke : ucitajPodatkeImp,
		iscrtajKalendar: iscrtajKalendarImp,
		inicijalizirajKalendar : inicijalizirajKalendarImp,
		redniBrojMjeseca : redniBrojMjesecaImp,
		podesiAktivniMjesec: podesiAktivniMjesecImp,
		osvjezi: osvjeziKalendarImp
	}
	
} () );

/*
var datumTrenutni = new Date();
var mjesecTrenutni = datumTrenutni.getMonth();

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesecTrenutni);

document.getElementById("btnNaredni").addEventListener("click", Kalendar.aktivniMjesecNaprijed);
document.getElementById("btnPrethodni").addEventListener("click", Kalendar.aktivniMjesecNazad);

var xhttp = new XMLHttpRequest();
xhttp.open("GET", "http://localhost:3000/podaciZauzeca", false);
xhttp.send();
var zauzecaJson = JSON.parse(xhttp.responseText);
var periodicnaZauzecaData = zauzecaJson.periodicnaZauzeca;
var vanrednaZauzecaData = zauzecaJson.vanrednaZauzeca;
*/
//console.log(periodicnaZauzeca);

/*
var periodicnaZauzecaData = [ { "dan":1, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }, 
							  { "dan":3, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							  { "dan":4, "semestar":"ljetni", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }] ;
var vanrednaZauzecaData = [ { "datum":"15.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"17.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"26.5.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"25.3.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac"}]; 
*/
/*					
Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);
Kalendar.inicijalizirajKalendar();
*/