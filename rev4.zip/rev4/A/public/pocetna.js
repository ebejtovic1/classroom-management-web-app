var trenutnaStranica = 0;
var ucitaneStranice = new Array();
var ukupnoStranica = 0;

function prikaziSlike(stranica) {
	
	// provjeri da li je ucitana stranica
	var ucitano = false;
	for (i=0; i < ucitaneStranice.length; i++) {
		if(ucitaneStranice[i].stranica == stranica){
			ucitano = true;
			break;
		}
	}
	
	//ako nije ucitano onda ucitaj i dodaj na niz
	if(!ucitano) {
		var slikeJson = Pozivi.ucitajNaredneSlike(trenutnaStranica);
		ucitaneStranice.push(slikeJson);
	}
	
	//postavi broj ukupnih stranica
	if (ukupnoStranica == 0) {
		ukupnoStranica = ucitaneStranice[trenutnaStranica].ukupnoStranica;
	}
	
	//ako slika postoji postavi src, ako ne postoji postavi na prazno
	if (ucitaneStranice[trenutnaStranica].slika1 != null) {
		document.getElementById("slika1").src = ucitaneStranice[trenutnaStranica].slika1;
	} else {
		document.getElementById("slika1").src = "";
	}
	
	if (ucitaneStranice[trenutnaStranica].slika2 != null) {
		document.getElementById("slika2").src = ucitaneStranice[trenutnaStranica].slika2;
	} else {
		document.getElementById("slika2").src = "";
	}
	
	if (ucitaneStranice[trenutnaStranica].slika3 != null) {
		document.getElementById("slika3").src = ucitaneStranice[trenutnaStranica].slika3;
	} else {
		document.getElementById("slika3").src = "";
	}
	
}

function naredneSlike() {
	
	if(trenutnaStranica < ukupnoStranica) {
		trenutnaStranica++;
		prikaziSlike(trenutnaStranica);
	}
	
	if(trenutnaStranica == ukupnoStranica) {
		document.getElementById("btnNaredni").disabled = true;
		document.getElementById("btnPrethodni").disabled = false;
	} else {
		document.getElementById("btnNaredni").disabled = false;
		document.getElementById("btnPrethodni").disabled = false;
	}
}

function prethodneSlike() {
	
	if(trenutnaStranica >= 0) {
		trenutnaStranica--;
		prikaziSlike(trenutnaStranica);
	}
	
	if (trenutnaStranica == 0) {
		document.getElementById("btnPrethodni").disabled = true;
		document.getElementById("btnNaredni").disabled = false;
	} else {
		document.getElementById("btnPrethodni").disabled = false;
		document.getElementById("btnNaredni").disabled = false;
	}
	
}

// listeneri za opcije naprijed i nazad
document.getElementById("btnNaredni").addEventListener("click", naredneSlike);
document.getElementById("btnPrethodni").addEventListener("click", prethodneSlike);

// inicijalizacija slika kada se tek stranica otvori
prikaziSlike(trenutnaStranica);
