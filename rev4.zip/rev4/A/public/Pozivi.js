let Pozivi = ( function () {
	
	function ucitajPodatkeAjaxImp() {
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/podaciZauzeca", false);
		xhttp.send();
		var zauzecaJson = JSON.parse(xhttp.responseText);
		return zauzecaJson;
	}
	
	function ucitajPodatkeBazaAjaxImp() {
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/podaciZauzecaBaza", false);
		xhttp.send();
		var zauzecaJson = JSON.parse(xhttp.responseText);
		return zauzecaJson;
	}
	
	function ucitajNaredneSlikeImp(stranica) {
		var urlZaPoziv = "/naredneSlike?brojStranice=" + stranica;
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", urlZaPoziv, false);
		xhttp.send();
		var slikeJson = JSON.parse(xhttp.responseText);
		return slikeJson;
	}
	
	function rezervacijaImp(dan, mjesec, godina, sala, periodicna, pocetak, kraj, osoba, salaNaziv) {
		
		//var urlZaPoziv ="";
		var urlZaPoziv = "/rezervacija?sala=" + sala + "&periodicna=" + periodicna + "&pocetak=" + pocetak + "&kraj=" + kraj + "&dan=" + dan + "&mjesec=" + mjesec + "&godina=" + godina + "&osoba=" + osoba + "&salaNaziv=" + salaNaziv ;
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", urlZaPoziv, false);
		xhttp.send();
		var odgovorJson = JSON.parse(xhttp.responseText);
		return odgovorJson;
		
	}
	
	function ucitajOsobeImp(){
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/osoblje", false);
		xhttp.send();
		var osobeJson = JSON.parse(xhttp.responseText);
		return osobeJson;
	}
	
	function ucitajSaleImp(){
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/sale", false);
		xhttp.send();
		var saleJson = JSON.parse(xhttp.responseText);
		return saleJson;
	}
	
	function ucitajOsobePoSalamaImp(){
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/osobeSale", false);
		xhttp.send();
		var saleJson = xhttp.responseText;
		return saleJson;
	}
	
	return {
		ucitajPodatkeAjax: ucitajPodatkeAjaxImp,	
		ucitajPodatkeBazaAjax: ucitajPodatkeBazaAjaxImp,
		ucitajNaredneSlike: ucitajNaredneSlikeImp,
		rezervacija: rezervacijaImp,
		ucitajOsobe: ucitajOsobeImp,
		ucitajSale: ucitajSaleImp,
		ucitajOsobePoSalama: ucitajOsobePoSalamaImp
	}
	
} () );