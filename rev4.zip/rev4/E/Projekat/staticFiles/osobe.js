window.onload = function(){
	Pozivi.listaOsoblja();
}

function azuriraj() {
	Pozivi.listaOsoblja();
}

setInterval(azuriraj, 30000);