var putanjeSlika = [];
// broj prve slike koja se prikazuje
// na pocetku se ne prikazuje ni jedna
var n = null;

function obradiOdgovor(odgovor) {
	if (odgovor.kraj) {
		// nema vise slika na serveru
		var sljedeci = document.getElementById("sljedeciButton");
		sljedeci.disabled = true;
	}
	var putanje = odgovor.putanje;
	var slike = document.getElementById("slike");
	// brisemo stare slike sa prikaza stranice
	while (slike.firstChild) {
			slike.removeChild(slike.firstChild);
	}
	for (var i = 0; i < putanje.length; i++) {
		// sacuvamo novu putanju
		putanjeSlika.push(putanje[i]);
		// prikazemo novu sliku na stranici
		slike.appendChild(vratiSlikaElement(putanje[i]));
	}
	// sljedeci put trazimo sljedece slike
	n += 3;
	// omoguciti dugme prethodni ako se trenutno ne prikazuju prve tri slike
	if (n > 3) {
		prethodni.disabled = false;
	}
}

// vraca DOM element u kojem ce se prikazati slika odredjena putanjom
function vratiSlikaElement(putanja) {
	var d = document.createElement("div");
	d.className = "divSlika";
	var i = document.createElement("img");
	i.src = putanja;
	d.appendChild(i);
	return d;
}

var prethodni = document.getElementById("prethodniButton");
prethodni.disabled = true;
// na pocetku cemo pokusati ucitati prve tri slike,
// zbog toga inicijaliziramo n na -2
n = -2;
Pozivi.ucitajSlike(n, obradiOdgovor);

// event handleri
{
	var prethodni = document.getElementById("prethodniButton");
	prethodni.addEventListener("click", function(ev) {
		// brisemo stare slike sa prikaza stranice
		while (slike.firstChild) {
			slike.removeChild(slike.firstChild);
		}
		// vracamo n da pokazuje na prvu sliku prethodnog dijela slika
		n -= 3;
		for (var i = 0; i < 3; i++) {
			// prikazujemo prethodne u htmlu
			slike.appendChild(vratiSlikaElement(putanjeSlika[n - 1 + i]));
		}
		// onemogociti dugme prethodni ako se trenutno prikazuju prve tri slike
		if (n < 4) {
			prethodni.disabled = true;
		}
		// omogociti dugme sljedeci ako ima jos slika poslije trenutno prikazanih
		if (n < putanjeSlika.length - 2) {
			sljedeci.disabled = false;
		}
		
	});
	
	var sljedeci = document.getElementById("sljedeciButton");
	console.log("?");
	sljedeci.addEventListener("click", function(ev) {
			Pozivi.ucitajSlike(n, obradiOdgovor);
	});
}