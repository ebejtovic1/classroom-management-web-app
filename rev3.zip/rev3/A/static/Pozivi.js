
// DA LI MJESEC U KALENDAR.JS TREBA BITI TRENUTNI ILI NOV/DEC?

let Pozivi = (function() {
	//
	//ovdje idu privatni atributi
	//
	
	function ucitajJSONZauzecaImpl(callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				var res = JSON.parse(ajax.responseText);
				callback(res.periodicna, res.vanredna);
			}
			if (ajax.readyState == 4 && ajax.status == 404) {
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		ajax.open('GET', "zauzeca.json");
		ajax.send();
	}
	
	function pokusajRezervisatiImpl(posiljka, periodicna, callbackUspjeh1, callbackUspjeh2, callbackUspjeh3, kalendarRef, mjesec, sala, 		pocetak, kraj, callbackNeuspjeh) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) { // termin je uspjesno rezervisan
				var zauzeca = JSON.parse(ajax.responseText);
				// JSON.parse ce dane predstaviti kao string, pretvaramo ih u Number
				for (var i = 0; i < zauzeca.periodicna.length; i++) {
					zauzeca.periodicna[i].dan = Number(zauzeca.periodicna[i].dan);
				}
				// ucitavamo podatke
				callbackUspjeh1(zauzeca.periodicna, zauzeca.vanredna);
				// bojimo dane na stranici
				callbackUspjeh2(kalendarRef, mjesec, sala, pocetak, kraj);
				// dodajemo event handlere danima
				callbackUspjeh3();
			} else if (ajax.readyState == 4 && ajax.status == 409) { // termin nije mogao biti rezervisan
				// prikazujemo poruku greske
				callbackNeuspjeh(ajax.responseText);				
			} else if (ajax.readyState == 4 && ajax.status == 404)
			{
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		// slanje zahtjeva
		posaljiZahtjevZaRezervaciju(posiljka, periodicna, ajax);
	}
	
	// salje zahtjev za rezervaciju
	function posaljiZahtjevZaRezervaciju(posiljka, periodicna, ajax) {
		if (periodicna) { // periodicno zauzece
			var rez = posiljka["rezervacija"];
			var datum = posiljka["datum"];
			ajax.open('POST', "dodajPeriodicnoZauzece");
			ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			ajax.send("dan=" + rez.dan + "&semestar=" + rez.semestar + "&pocetak=" + rez.pocetak + "&kraj=" + rez.kraj + 
				"&naziv=" + rez.naziv + "&predavac=" + rez.predavac + "&odabraniDan=" + datum.odabraniDan + "&mjesec=" +
				datum.mjesec + "&godina=" + datum.godina);
		} else { // vanredno zauzece
			ajax.open('POST', "dodajVanrednoZauzece");
			ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			ajax.send("datum=" + posiljka.datum + "&pocetak=" + posiljka.pocetak + "&kraj=" + posiljka.kraj + 
				"&naziv=" + posiljka.naziv + "&predavac=" + posiljka.predavac);
		}
	}
	
	/*
	// provjeriti da li je sala zauzeta u terminu
	function jeLiZauzeta(rez, zauzeca) {
		// provjeri periodicna zauzeca
		for (var i = 0; i < periodicna.length; i++) {
			if (jeLiSePreklapajuPeriodicno(rez1, periodicna[i])) {
				callbackNeuspjeh(rez1);
				return;
			}
		}
		
		// provjeri vanredna zauzeca
	}
	
	function jeLiSePreklapaju(rez1, rez2) {
		if (rez1.naziv !== rez2.sala) {
			return false;
		}
		if (!((rez1.pocetak <= rez2.pocetak && rez1.kraj > rez2.pocetak) || 
			(rez1.pocetak >= rez2.pocetak && rez1.pocetak < rez2.kraj))) {
			return false;
		}
		if (rez1.semestar !== rez2.semestar) {
				return false;
		}
		// svi testovi su prosli, rezervacije se preklapaju
		return true;
	}
	*/
	
	function ucitajSlikeImpl(n, callback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				var res = JSON.parse(ajax.responseText);
				callback(res);
			}
			if (ajax.readyState == 4 && ajax.status == 404) {
				document.getElementById("body").innerHTML = "Greska: nepoznat URL";
			}
		}
		// trazimo sljedece tri slike
		ajax.open('GET', "slike/" + (n + 3));
		ajax.send();
	}
	
	return {
		ucitajJSONZauzeca: ucitajJSONZauzecaImpl,
		pokusajRezervisati: pokusajRezervisatiImpl,
		ucitajSlike: ucitajSlikeImpl
	}
})();
