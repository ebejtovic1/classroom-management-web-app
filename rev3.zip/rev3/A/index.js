const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
app.use(express.static(path.join(__dirname + '/static')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
	res.sendFile(path.join(__dirname, 'pocetna.html'));
});

app.get('/zauzeca.json', (req, res) => {
	res.sendFile(path.join(__dirname, 'zauzeca.json'));
});

app.get('/pocetna', (req, res) => {
	res.sendFile(path.join(__dirname, 'pocetna.html'));
});

app.get('/sale', (req, res) => {
	res.sendFile(path.join(__dirname, 'sale.html'));
});

app.get('/unos', (req, res) => {
	res.sendFile(path.join(__dirname, 'unos.html'));
});

app.get('/rezervacija', (req, res) => {
	res.sendFile(path.join(__dirname, 'rezervacija.html'));
});

app.get('/slike/:n', (req, res) => {
	var rezultat = {kraj: false, putanje: []};
	var n = req.params.n;
	traziSlike(res, Number(n), 0, rezultat);
});

function traziSlike(res, n, i, rezultat) {
	fs.access("static/" + (n + i) + ".jpg", fs.constants.F_OK, function(err) {
		if (err) {
			// slika ne postoji
			// oznacavamo kraj slika
			rezultat.kraj = true;
		} else {
			// dodajemo putanju slike u rezultat
			rezultat.putanje.push((n + i) + ".jpg");
		}
		
		if (err || i === 2) { // nasli smo trecu ili zadnju sliku
			res.send(rezultat);
		} else {
			// nastavljamo rekurzivne pozive
			traziSlike(res, n, i + 1, rezultat);
		}
	});
}


app.post('/dodajPeriodicnoZauzece', (req, res) => {
	var tijelo = req.body;
	var novoZauzece = {"dan": Number(tijelo.dan), "semestar": tijelo.semestar, "pocetak": tijelo.pocetak, "kraj": tijelo.kraj, 
		"naziv": tijelo.naziv, "predavac": tijelo.predavac};
	var datum = {"odabraniDan" : tijelo.odabraniDan, "mjesec" : tijelo.mjesec, "godina" : tijelo.godina};
	
	// Asinhrono dobavljanje i koristenje podataka
	fs.readFile('zauzeca.json', function obradiPeriodicniZahtjev(err, data) {
		if (err) {
			console.log(err);
		} else {
			var zauzeca = JSON.parse(data);
			// JSON.parse ce dane predstaviti kao string, pretvaramo ih u Number
			for (var i = 0; i < zauzeca.periodicna.length; i++) {
				zauzeca.periodicna[i].dan = Number(zauzeca.periodicna[i].dan);
			}
			// testiramo
			if (!testirajPreklapanja(novoZauzece, true, zauzeca)) {
				// dodati novo periodicno zauzece
				zauzeca.periodicna.push(novoZauzece);
				var jsonZaUpisati = JSON.stringify(zauzeca);
				// Asinhrono upisivanje i vracanje podataka
				fs.writeFile('zauzeca.json', jsonZaUpisati, 'utf8', (err) => {
					if (err) {
						throw err;
					} else {
						res.sendFile(path.join(__dirname, 'zauzeca.json'));
					}
				});
			} else { // vec postoji
				// status konflikta sa stanjem na serveru
				res.status(409);
				var porukaGreske = "Nije moguće rezervisati salu " + novoZauzece.naziv + " za navedeni datum " + 
					dajStringDatuma(datum.odabraniDan, datum.mjesec, datum.godina) + " i termin od " + novoZauzece.pocetak
					+ " do " + novoZauzece.kraj + "!";
				res.send(porukaGreske);
				
			}
		}
	});
});

app.post('/dodajVanrednoZauzece', (req, res) => {
	var tijelo = req.body;
	var novoZauzece = {"datum": tijelo.datum, "pocetak": tijelo.pocetak, "kraj": tijelo.kraj, 
		"naziv": tijelo.naziv, "predavac": tijelo.predavac};
	// Asinhrono dobavljanje i koristenje podataka
	fs.readFile('zauzeca.json', function obradiVanredniZahtjev(err, data) {
		if (err) {
			console.log(err);
		} else {
			var zauzeca = JSON.parse(data);
			if (!testirajPreklapanja(novoZauzece, false, zauzeca)) {
				// nema preklapanja
				// dodati novo vanredno zauzece
				zauzeca.vanredna.push(novoZauzece);
				var jsonZaUpisati = JSON.stringify(zauzeca);
				// Asinhrono upisivanje i vracanje podataka
				fs.writeFile('zauzeca.json', jsonZaUpisati, 'utf8', (err) => {
					if (err) {
						throw err;
					} else {
						res.sendFile(path.join(__dirname, 'zauzeca.json'));
					}
				});
			} else {
				// ima preklapanja
				// status konflikta sa stanjem na serveru
				res.status(409);
				var porukaGreske = "Nije moguće rezervisati salu " + novoZauzece.naziv + " za navedeni datum " + 
					novoZauzece.datum + " i termin od " + novoZauzece.pocetak + " do " + novoZauzece.kraj + "!";
				res.send(porukaGreske);
				
			}
		}
	});
});

// pokreni server
app.listen(8080, () => {});


// pomocne funkcije

function dajStringDatuma(d, m, y) {
	var d = new Date(y, m, d);
	var str = "";
	if (d.getDate() < 10) {
		str += "0" + d.getDate();
	} else {
		str += d.getDate();
	}
	str += ".";
	if (d.getMonth() + 1 < 10) {
		str += "0" + d.getMonth() + 1;
	} else {
		str += d.getMonth() + 1;
	}
	return str + "." + d.getFullYear();
}

function testirajPreklapanja(novoZauzece, periodicno, zauzeca) {
	var p = zauzeca.periodicna;
	var v = zauzeca.vanredna;
	// testiramo preklapanja sa periodicnim zauzecima
	for (var i = 0; i < p.length; i++) {
		if (periodicno) {
			if (testirajPerPer(novoZauzece, p[i])) {
				return true;
			}
		} else {
			if (testirajPerVan(p[i], novoZauzece)) {
				return true;
			}
		}
	}
	
	for	(var i = 0; i < v.length; i++) {
		if (periodicno) {
			if (testirajPerVan(novoZauzece, v[i])) {
				return true;
			}
		} else {
			if (testirajVanVan(novoZauzece, v[i])) {
				return true;
			}
		}
	}
	return false;
}

function testirajPerPer(p1, p2) {
	// testiramo jednakost naziva sale, semestra, i dana
	if ((p1.naziv != p2.naziv) || (p1.semestar != p2.semestar) || (p1.dan != p2.dan)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((p1.pocetak <= p2.pocetak && p1.kraj > p2.pocetak) || (p1.pocetak >= p2.pocetak && p1.pocetak < p2.kraj))) {
		return false;
	}
	return true;
}

function testirajVanVan(v1, v2) {
	// testiramo jednakost naziva sale i datuma
	if ((v1.naziv != v2.naziv) || (v1.datum != v2.datum)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((v1.pocetak <= v2.pocetak && v1.kraj > v2.pocetak) || (v1.pocetak >= v2.pocetak && v1.pocetak < v2.kraj))) {
		return false;
	}
	return true;
}

function testirajPerVan(p, v) {
	// testiramo jednakost naziva sale
	if ((p.naziv != v.naziv)) {
		return false;
	}
	// provjera da li mjesec pripada semestru
	if (p.semestar === "zimski" && (v.mjesec > 0 || v.mjesec < 9)) {
			return false;
		}
	if (p.semestar === "ljetni" && (v.mjesec < 1 || v.mjesec > 5)) {
		return false;
	}
	// testiramo preklapanja sati termina
	if (!((p.pocetak <= v.pocetak && p.kraj > v.pocetak) || (p.pocetak >= v.pocetak && p.pocetak < v.kraj))) {
		return false;
	}
	if (p.dan != dajRedniBrojDana(v.datum)) {
		return false;
	}
	return true;
}

function dajRedniBrojDana(str) {
	var date = new Date();
	var dayofweek = new Date(Number(str.substring(6, 10)), Number(str.substring(3, 5)) - 1, 1).getDay();
	// dayofweek je redni broj u sedmici prvog dana mjeseca, pocevsi od nule
	dayofweek = (dayofweek + 6) % 7;
	// danUSedmici je redni broj dana u sedmici, pocevsi od nule
	var danUSedmici = (Number(str.substring(0, 2)) + dayofweek - 1) % 7;
	return danUSedmici;
}

