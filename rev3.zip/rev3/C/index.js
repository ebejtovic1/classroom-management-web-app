const express = require('express');
const bodyParser = require('body-parser');

const loadImageData = require('./images');
const reservations = require('./reservations');

const PORT = 8080;
const app = express();

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.redirect('/pocetna.html');
});

app.get('/zauzeca/periodicna', (req, res) => {
    reservations.getPeriodicnaZauzeca(
        periodicna => {
            res.json(periodicna);
        },
        _ => {
            res.json({
                message: 'Greska!'
            });
        }
    );
});

app.get('/zauzeca/vanredna', (req, res) => {
    reservations.getVanrednaZauzeca(
        vanredna => {
            res.json(vanredna);
        },
        _ => {
            res.json({
                message: 'Greska!'
            });
        }
    );
});

app.post('/zauzeca/periodicna', (req, res) => {
    const { dan, semestar, naziv, pocetak, kraj, predavac } = req.body;
    const zauzece = {
        dan, semestar, naziv, pocetak, kraj, predavac
    }

    reservations.rezervisiPeriodicno(zauzece, zauzeca => res.json(zauzeca), err => res.json(err));
});

app.post('/zauzeca/vanredna', (req, res) => {
    const { datum, naziv, pocetak, kraj, predavac } = req.body;
    const zauzece = {
        naziv, datum, pocetak, kraj, predavac
    };

    reservations.rezervisiVanredno(zauzece, zauzeca => res.json(zauzeca), err => res.json(err));
});

app.post('/slike', (req, res) => {
    let imageData = req.body.imageData;

    loadImageData(imageData, newImageData => {
        res.json(newImageData);
    });
});

app.listen(PORT, () => {
    console.log(`Server started at port ${PORT}...`)
});
