let assert = chai.assert;
let expect = chai.expect;

const kalendarRef = document.querySelector('.kalendar');

function iscrtajKalendar(mjesec) {
    Kalendar.iscrtajKalendar(kalendarRef, mjesec);
}

function dani() {
    return Array.from(kalendarRef.querySelectorAll('.dani .celija:not(.invisible)'));
}

function dajSadrzajCelija() {
    let celije = Array.from(kalendarRef.querySelectorAll('.dani .celija:not(.invisible) .sadrzaj-celije'));
    return celije.map(celija => celija.innerHTML);
}

function zauzetostDana() {
    const zauzecaCelije = Array.from(kalendarRef.querySelectorAll('.dani .celija:not(.invisible) .zauzetost-celije'));
    return zauzecaCelije.map((zauzece, index) => {
        const zauzeto = zauzece.classList.contains('zauzeta');
        const dan = index + 1;
        return {
            dan, zauzeto
        }
    });
}

function offsetDana() {
    return kalendarRef.querySelectorAll('.dani .celija.invisible').length;
}

function danUSedmiciDana(dan) {
    return (offsetDana() + dan - 1) % 7 + 1;
}

describe('Kalendar', () => {
    describe('iscrtajKalendar', () => {
        it('Iscrtavanje kalendara za mjesec sa 30 dana - Novembar', () => {
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            assert.equal(30, dani().length);
        });

        it('Iscrtavanje kalendara za mjesec sa 31 dan - Oktobar', () => {
            Kalendar.iscrtajKalendar(kalendarRef, 9);
            assert.equal(31, dani().length);
        });

        it('Prvi dan novembra u 2019. je petak', function() {
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            assert.equal(5, danUSedmiciDana(1));
        });

        it('30. dan novembra u 2019. je subota', function() {
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            assert.equal(6, danUSedmiciDana(30));
        });

        it('Dani idu 1 do 31 od utorka - Januar', function() {
            Kalendar.iscrtajKalendar(kalendarRef, 0);
            const sadrzajCelija = dajSadrzajCelija().map(str => parseInt(str));
            const ocekivaniSadrzaj = new Array(31).fill(0).map((_, i) => i + 1);
            expect(sadrzajCelija).to.eql(ocekivaniSadrzaj);
        });
        // --- Moji testovi ---
        it('Jedanaesti dan oktobra u 2019. je petak', () => {
            Kalendar.iscrtajKalendar(kalendarRef, 9);
            assert.equal(5, danUSedmiciDana(11));
        });

        it('Novembar 2019. ima 5 sedmica', () => {
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            const danUSedmiciPrvog = danUSedmiciDana(1);
            const ukupnoCelija = dani().length + danUSedmiciPrvog - 2;
            let brojSedmica = Math.floor(ukupnoCelija / 7);
            brojSedmica = brojSedmica % 7 > 0 ? brojSedmica + 1 : brojSedmica;
            assert.equal(5, brojSedmica);
        });
    });

    describe('ucitajPodatke i obojiZauzeca', () => {
        it('Pozivanje obojiZauzeca kada podaci nisu učitani', () => {
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '09:00', '12:00');
            const zauzetost = zauzetostDana().map(dan => dan.zauzeto);
            expect(zauzetost).to.be.an('array').that.does.not.include(true);
        });

        it('Postoje duple vrijednosti za zauzeće istog termina', () => {
            const zauzece = {
                dan: 3,
                semestar: 'zimski',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };
            Kalendar.ucitajPodatke([], [zauzece, zauzece]);
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');
            
            const zauzetost = zauzetostDana().filter(dan => dan.zauzeto);
            expect(zauzetost).not.to.be.empty;
        });

        it('Postoji zauzece u drugom semestru', () => {
            const ljetno = {
                dan: 4,
                semestar: 'ljetni',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };

            Kalendar.ucitajPodatke([], [ljetno]);
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');

            const zauzetost = zauzetostDana().filter(dan => dan.zauzeto);
            expect(zauzetost).to.be.empty;
        });

        it('U podacima postoji zauzeće termina ali u drugom mjesecu', () => {
            const zauzece = {
                datum: '10.10.2019',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            }

            Kalendar.ucitajPodatke([zauzece], []);
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');

            const danZauzet = zauzetostDana().filter(zauzece => zauzece.dan == 10)[0].zauzeto;
            expect(danZauzet).to.be.false;
        });

        it('U podacima svi termini u mjesecu zauzeti', () => {
            const zauzeca = [1, 2, 3, 4, 5, 6, 7].map(i => ({
                dan: i,
                semestar: 'zimski',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            }));

            Kalendar.ucitajPodatke([], zauzeca);
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');

            const slobodniDani = zauzetostDana().filter(dan => !dan.zauzeto);
            expect(slobodniDani).to.be.empty;
        });

        it('Dva puta uzastopno pozivanje obojiZauzece', () => {
            const zauzece = {
                datum: '10.11.2019',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };
            Kalendar.iscrtajKalendar(kalendarRef, 10);

            Kalendar.ucitajPodatke([zauzece], []);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');
            Kalendar.ucitajPodatke([], []);

            const danZauzet = zauzetostDana().filter(zauzece => zauzece.dan == 10)[0].zauzeto;
            expect(danZauzet).to.be.true;
        });

        it('Cisceneje starih zauzeca nakon ucitavanja i bojenja novih', () => {
            const zauzece = {
                datum: '10.11.2019',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };
            Kalendar.iscrtajKalendar(kalendarRef, 10);

            Kalendar.ucitajPodatke([zauzece], []);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');
            const danZauzet = zauzetostDana().filter(zauzece => zauzece.dan == 10)[0].zauzeto;
            
            Kalendar.ucitajPodatke([], []);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');
            const danZauzet2 = zauzetostDana().filter(zauzece => zauzece.dan == 10)[0].zauzeto;

            expect(danZauzet).not.to.be.equal(danZauzet2);
        });
        // --- Moji testovi ---
        it('Preklapanje redovnog i vanrednog zauzeca', () => {
            const vanredno = {
                datum: '7.11.2019',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };
            const redovno = {
                dan: 4,
                semestar: 'zimski',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };
            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.ucitajPodatke([vanredno], [redovno]);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');

            const zauzetoNaSedmi = zauzetostDana().filter(zauzece => zauzece.dan == 7)[0].zauzeto;
            expect(zauzetoNaSedmi).to.be.true;
        });
        
        it('Redovna zauzeca fkt svake sedmice', () => {
            const redovno = {
                dan: 4,
                semestar: 'zimski',
                naziv: 'A3',
                pocetak: '09:00',
                kraj: '12:00',
                predavac: 'Jason'
            };

            Kalendar.iscrtajKalendar(kalendarRef, 10);
            Kalendar.ucitajPodatke([], [redovno]);
            Kalendar.obojiZauzeca(kalendarRef, 10, 'A3', '08:00', '13:00');

            const daniNaCetvrtak = zauzetostDana().filter(zauzece => danUSedmiciDana(zauzece.dan) == 4);
            const brojZauzetih = daniNaCetvrtak.filter(dan => dan.zauzeto).length;
            expect(brojZauzetih).to.be.equal(4);
        });
    });

});
