const fs = require('fs');

function getPeriodicnaZauzeca(callback, error_callback) {
    getZauzeca(zauzeca => callback(zauzeca.periodicna), error_callback);
}

function getVanrednaZauzeca(callback, error_callback) {
    getZauzeca(zauzeca => callback(zauzeca.vanredna), error_callback);
}

function getZauzeca(callback, error_callback) {
    fs.readFile('zauzeca.json', (err, data) => {
        if(err) {
            error_callback(err);
            return;
        }
        const zauzeca = JSON.parse(data.toString());
        callback(zauzeca);
    });
}

function timeIntervalValid(zauzece) {
    return zauzece.pocetak <= zauzece.kraj;
}

function rezervisiVanredno(zauzece, success, fail) {
    getZauzeca(zauzeca => {
        if(!timeIntervalValid(zauzece)) {
            fail({
                ...zauzeca,
                err: 'Greška: vijeme početka nakon vremena kraja intervala!'
            });
            return;
        }

        if(zauzece.semestar == 'odmor') {
            fail({
                ...zauzeca,
                err: 'Nije moguće napraviti periodičnu rezervaciju za odmor!'
            });
            return;
        }

        if(zauzetoVanredno(zauzece, zauzeca)) {
            const { naziv, datum, pocetak, kraj } = zauzece;
            fail({
                ...zauzeca,
                err: `Nije moguće rezervisati salu ${naziv} za navedeni datum ${datum} i termin od ${pocetak} do ${kraj}!`
            });
        } else {
            zauzeca.vanredna.push(zauzece);
            zapisiZauzeca(zauzeca, () => {
                success(zauzeca);
            });
        }
    }, err => {
        console.log(err);
    });
}

function rezervisiPeriodicno(zauzece, success, fail) {
    getZauzeca(zauzeca => {
        if(zauzetoPeriodicno(zauzece, zauzeca)) {
            const { naziv, dan, pocetak, kraj } = zauzece;
            fail({
                ...zauzeca,
                err: `Nije moguće rezervisati salu ${naziv} za ${dan}. dan i termin od ${pocetak} do ${kraj}!`
            });
        } else {
            zauzeca.periodicna.push(zauzece);
            zapisiZauzeca(zauzeca, () => {
                success(zauzeca);
            });
        }
    }, err => {
        console.log(err);
    });
}

function vanrednoToRedovno(vanredno) {
    const { naziv, pocetak, kraj, predavac, datum } = vanredno;

    const dateSplit = datum.split('.');
    const danUMjesecu = dateSplit[0];
    const mjesec = dateSplit[1] - 1;
    const monthData = dajPodatkeOMjesecu(mjesec);
    let dan = (monthData.danUSedmici + (danUMjesecu - 1) % 7) % 7;
    if(dan == 0)
        dan = 7;
    
    const semestar = dajSemestarPoMjesecu(mjesec);

    return {
        naziv,
        pocetak,
        kraj,
        predavac,
        semestar,
        dan
    };
}

function zauzetoPeriodicno(periodicno, zauzeca) {
    const periodicna = zauzeca.vanredna.map(vanredno => vanrednoToRedovno(vanredno));
    const svaPeriodicna = [...zauzeca.periodicna, ...periodicna];

    const match = svaPeriodicna.filter(trenutno => matchPeriodicna(periodicno, trenutno));

    return match.length > 0;
}

function matchPeriodicna(periodicno, trenutno) {
    const uIntervalu = zauzeceUIntervalu(periodicno, trenutno.pocetak, trenutno.kraj);
    const istaSala = periodicno.naziv == trenutno.naziv;
    const istiDan = periodicno.semestar == trenutno.semestar && periodicno.dan == trenutno.dan;
    return uIntervalu && istaSala && istiDan;
}

function zauzetoVanredno(vanredno, zauzeca) {
    const periodicno = vanrednoToRedovno(vanredno);

    const uPeriodicnim = zauzeca.periodicna.filter(trenutno => matchPeriodicna(periodicno, trenutno));
    const uVanrednim = zauzeca.vanredna.filter(trenutno => matchVanredna(vanredno, trenutno));
    
    return uPeriodicnim.length > 0 || uVanrednim.length > 0;
}

function matchVanredna(vanredno, trenutno) {
    const istiDan = vanredno.datum == trenutno.datum;
    const uIntervalu = zauzeceUIntervalu(vanredno, trenutno.pocetak, trenutno.kraj);
    const istaSala = vanredno.naziv == trenutno.naziv;
    return uIntervalu && istaSala && istiDan;
}

function zauzeceUIntervalu(zauzece, pocetak, kraj) {
    if(zauzece.pocetak > zauzece.kraj)
        return false;
    return zauzece.kraj >= pocetak && zauzece.pocetak <= kraj;
}

function dajSemestarPoMjesecu(mjesec) {
    if(mjesec < 1 || mjesec >= 9)
        return 'zimski';
    if(mjesec >= 1 && mjesec <= 5)
        return 'ljetni';
    return 'odmor';
}

function dajPodatkeOMjesecu(mjesec) {
    const msUDanu = 1000 * 60 * 60 * 24;
    const prviUMjesecu = new Date(new Date().getFullYear(), mjesec, 1);
    const brojDanaUMjesecu = new Date(prviUMjesecu.getFullYear(), mjesec+1, 0).getDate();
    let danUSedmici = prviUMjesecu.getDay();
    
    if(danUSedmici == 0)
        danUSedmici = 7;

    const brojDana = brojDanaUMjesecu + danUSedmici - 2;
    const brojSedmicaSimple = Math.floor(brojDana / 7);
    const brojSedmica = brojSedmicaSimple % 7 > 0 ? brojSedmicaSimple + 1 : brojSedmicaSimple;

    return {
        prviUMjesecu,
        danUSedmici,
        brojDanaUMjesecu,
        brojSedmica,
        msUDanu
    }
}

function zapisiZauzeca(zauzeca, callback) {
    fs.writeFile('zauzeca.json', JSON.stringify(zauzeca, null, 2), callback);
}

module.exports = {
    getPeriodicnaZauzeca,
    getVanrednaZauzeca,
    rezervisiPeriodicno,
    rezervisiVanredno
}
