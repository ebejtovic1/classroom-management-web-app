let Kalendar = function(){
    let redovna = [];
    let vanredna = [];
    let { zauzeceUIntervalu, dajSemestarPoMjesecu, dajPodatkeOMjesecu } = KalendarUtils;

    const daniLabel = ['PON', 'UTO', 'SRI', 'ČET', 'PET', 'SUB', 'NED'];

    function odbojiZauzeca(zauzetostCelije) {
        zauzetostCelije.forEach(dan => {
            dan.classList.remove('zauzeta');
            dan.classList.add('slobodna');
        });
    }

    function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj) {
        const dani = kalendarRef.querySelectorAll('.dani .celija .zauzetost-celije');
        odbojiZauzeca(dani);

        const date = dajPodatkeOMjesecu(mjesec);
        const semestar = dajSemestarPoMjesecu(mjesec);

        let redovnaIzSemestra = redovna.filter(redovno => redovno.semestar == semestar);
        let vanrednaZaMjesec = vanredna.filter(vanredno => {
            let mjesecZauzeca = vanredno.datum.split('.')[1];
            let mjesecReal = mjesec + 1;
            return mjesecZauzeca == mjesecReal;
        });
        const zauzeceFilter = zauzece => {
            let uIntervalu = zauzeceUIntervalu(zauzece, pocetak, kraj);
            return zauzece.naziv == sala && uIntervalu;
        }
        
        redovnaIzSemestra = redovnaIzSemestra.filter(zauzeceFilter);
        vanrednaZaMjesec = vanrednaZaMjesec.filter(zauzeceFilter);

        redovnaIzSemestra.forEach(redovno => {
            for(let i = 0; i < date.brojSedmica; i++) {
                const index = i * 7 + redovno.dan - 1;
                if(index < dani.length)
                    dani[index].classList.add('zauzeta');
            }
        });

        vanrednaZaMjesec.forEach(vanredno => {
            const newDateStr = vanredno.datum.split('.').reverse().join('-');
            const vanrednoDatum = new Date(newDateStr);
            const dan = Math.floor((vanrednoDatum - date.prviUMjesecu) / date.msUDanu);
            const index = date.danUSedmici - 1 + dan;
            dani[index].classList.add('zauzeta');
        });
    }

    function ucitajPodatke(vanrednaZauzeca, redovnaZauzeca) {
        redovna = redovnaZauzeca;
        vanredna = vanrednaZauzeca;
    }
    
    function iscrtajKalendar(kalendarRef, mjesec) {
        const date = dajPodatkeOMjesecu(mjesec);

        const nazivMjeseca = date.prviUMjesecu.toLocaleString('bs', { month: 'long' });
        const mjesecHeader = `<p class="mjesec">${nazivMjeseca}</p>`;
        
        const daniHeader = `
        <div class="dani-header">
        ${daniLabel.map(dan => makeDanCell(dan)).join('')}
        </div>
        `;

        const brojDana = window.innerWidth > 600 ? date.brojDanaUMjesecu : 7 - date.danUSedmici + 1;
        const daniUMjesecu = new Array(brojDana).fill(0).map((_, index) => makeCell(index + 1)).join('');

        const offset = new Array(date.danUSedmici-1).fill(0).map(_ => makeCell(0, true)).join('');

        const dani = `
        <div class="dani">${offset} ${daniUMjesecu}</div>
        `;

        kalendarRef.innerHTML = `${mjesecHeader} ${daniHeader} ${dani}`;
    }

    function makeDanCell(data) {
        return `
        <div class="celija">
            <div class="sadrzaj-celije dan">${data}</div>
            <div class="zauzetost-celije invisible"></div>
        </div>
        `;
    }

    function makeCell(data, invisible = false) {
        return `
        <div class="celija ${invisible ? 'invisible' : ''}">
            <div class="sadrzaj-celije">${data}</div>
            <div class="zauzetost-celije slobodna"></div>
        </div>
        `;
    }

    function getZauzeca() {
        return {
            periodicna: redovna,
            vanredna
        };
    }

    return {
        obojiZauzeca,
        ucitajPodatke,
        iscrtajKalendar,
        getZauzeca
    }
}();
