let Pozivi = function(){

    function fetchJson(url, callback, error_callback) {
        fetch(url)
        .then(res => res.json())
        .then(json => callback(json))
        .catch(err => error_callback(err));
    }

    function getPeriodicna(callback, error_callback) {
        fetchJson('/zauzeca/periodicna', callback, error_callback);
    }

    function getVanredna(callback, error_callback) {
        fetchJson('/zauzeca/vanredna', callback, error_callback);
    }

    function rezervisi(type, zauzece, callback, error_callback) {
        fetch(`/zauzeca/${type}`, {
            method: 'post',
            cache: 'no-cache',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(zauzece)
        })
        .then(res => res.json())
        .then(json => callback(json))
        .catch(err => error_callback(err));
    }

    function rezervisiVanredno(zauzece, callback, error_callback) {
        rezervisi('vanredna', zauzece, callback, error_callback);
    }

    function rezervisiPeriodicno(zauzece, callback, error_callback) {
        rezervisi('periodicna', zauzece, callback, error_callback);
    }

    function getImageData(imageData, callback, error_callback) {
        fetch('/slike', {
            method: 'POST',
            cache: 'no-cache',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ imageData })
        })
        .then(res => res.json())
        .then(json => callback(json))
        .catch(err => error_callback(err));
    }

    function getImage(name, callback, error_callback) {
        fetch('/' + name)
        .then(image => callback(image))
        .catch(err => error_callback(err));
    }

    return {
        getPeriodicna,
        getVanredna,
        rezervisiVanredno,
        rezervisiPeriodicno,
        getImageData,
        getImage
    };
}();