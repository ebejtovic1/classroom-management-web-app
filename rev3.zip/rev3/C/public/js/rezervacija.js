const Rezervacija = function() {
    let data = {};
    const DOMElems = {};
    let wideScreen = true;

    function nextMonth() {
        if(data.mjesec < 11)
            data.mjesec++;
        iscrtajKalendarIObojiZauzeca();
    }

    function prevMonth() {
        if(data.mjesec > 0)
            data.mjesec--;
        iscrtajKalendarIObojiZauzeca();
    }

    function normalizedAMPM(vrijeme) {
        let [hh, mm] = vrijeme.split(':');
        if(hh == '00')
            hh = '12';
        else if(hh == 12)
            hh = '00';
        return `${hh}:${mm}`;
    }

    function obojiZauzeca() {
        let pocetak = normalizedAMPM(data.pocetak);
        let kraj = normalizedAMPM(data.kraj);
        Kalendar.obojiZauzeca(DOMElems.kalendar, data.mjesec, data.sala, pocetak, kraj);
    }

    function iscrtajKalendarIObojiZauzeca() {
        Kalendar.iscrtajKalendar(DOMElems.kalendar, data.mjesec);
        Kalendar.obojiZauzeca(DOMElems.kalendar, data.mjesec, data.sala, data.pocetak, data.kraj);
        setDateEventListener();
    }

    function setDateEventListener() {
        const cells = document.querySelectorAll('.dani .celija:not(.invisible)');

        cells.forEach(cell => {
            const dan = cell.querySelector('.sadrzaj-celije').innerHTML;
            cell.addEventListener('click', e => {
                reserve(dan);
            });
        });
    }

    function reserve(dan) {
        if(confirm('Da li želite da rezervišete ovaj termin?')) {
            if(!timeIntervalValid()) {
                alert('Greška: vijeme početka nakon vremena kraja intervala!');
                return;
            }

            const zauzece = getZauzece(dan);
            const isZauzeto = data.periodicno ? KalendarUtils.zauzetoPeriodicno : KalendarUtils.zauzetoVanredno;
            const reserveMethod = data.periodicno ? Pozivi.rezervisiPeriodicno : Pozivi.rezervisiVanredno;

            if(zauzece.semestar == 'odmor') {
                alert('Nije moguće napraviti periodičnu rezervaciju za odmor!');
                return;
            }

            if (isZauzeto(zauzece, Kalendar.getZauzeca())) {
                const message = data.periodicno ? 
                    `Nije moguće rezervisati salu ${zauzece.naziv} za navedeni datum ${zauzece.datum} i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`
                    : `Nije moguće rezervisati salu ${zauzece.naziv} za ${dan}. dan i termin od ${zauzece.pocetak} do ${zauzece.kraj}!`;
                alert(message);
                return;
            }

            reserveMethod(
                zauzece,
                res => {
                    if(res.err)
                        alert(res.err);
                    
                    Kalendar.ucitajPodatke(res.vanredna, res.periodicna);
                    iscrtajKalendarIObojiZauzeca();
                }, err => console.log(err)
            );
        }
    }

    function timeIntervalValid() {
        return data.pocetak <= data.kraj;
    }

    function getZauzece(dan) {
        let { mjesec, pocetak, kraj, sala, periodicno } = data;

        let zauzece = {
            pocetak,
            kraj,
            naziv: sala,
            predavac: 'Predavac',
        };

        if(periodicno) {
            const monthData = KalendarUtils.dajPodatkeOMjesecu(mjesec);
            let danUSedmici = (monthData.danUSedmici + (dan - 1) % 7) % 7;
            if(danUSedmici == 0)
                danUSedmici = 7;
            zauzece.dan = danUSedmici;
            zauzece.semestar = KalendarUtils.dajSemestarPoMjesecu(mjesec);
        } else {
            const godina = new Date().getFullYear();
            const datum = `${dan}.${mjesec+1}.${godina}`;
            zauzece.datum = datum;
        }

        return zauzece;
    }

    function loadDOMElements() {
        DOMElems.kalendar = document.querySelector('.kalendar');
        DOMElems.prethodni = document.getElementById('prethodni');
        DOMElems.sljedeci = document.getElementById('sljedeci');
        DOMElems.sala = document.getElementById('sala');
        DOMElems.periodicno = document.getElementById('periodicno');
        DOMElems.pocetak = document.getElementById('pocetak');
        DOMElems.kraj = document.getElementById('kraj');
    }

    function initEventHandlers() {
        DOMElems.prethodni.addEventListener('click', _ => prevMonth());
        DOMElems.sljedeci.addEventListener('click', _ => nextMonth());

        [DOMElems.sala, DOMElems.pocetak, DOMElems.kraj].forEach(input => {
            input.addEventListener('change', e => {
                data[e.target.name] = e.target.value;
                obojiZauzeca();
            });
        });

        DOMElems.periodicno.addEventListener('click', e => {
            data.periodicno = e.target.checked;
        });

        window.onresize = e => {
            if(e.target.innerWidth > 600) {
                if(!wideScreen) {
                    wideScreen = true;
                    iscrtajKalendarIObojiZauzeca();
                }
            } else {
                if(wideScreen) {
                    wideScreen = false;
                    iscrtajKalendarIObojiZauzeca();
                }
            }
        }
    }

    function initData() {
        data = {
            mjesec: new Date().getMonth(),
            sala: DOMElems.sala.value,
            pocetak: DOMElems.pocetak.value,
            kraj: DOMElems.kraj.value,
            periodicno: DOMElems.periodicno.checked
        }

        wideScreen = window.innerWidth > 600;
    }

    function main() {
        loadDOMElements();
        initEventHandlers();
        initData();

        Pozivi.getPeriodicna(periodicna => {
            Pozivi.getVanredna(vanredna => {
                Kalendar.ucitajPodatke(vanredna, periodicna);
                iscrtajKalendarIObojiZauzeca();
            }, err => console.log(err))
        }, err => console.log(err));
    }

    return main;
}();

Rezervacija();
