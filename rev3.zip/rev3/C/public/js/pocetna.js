const Pocetna = function() {
    let elems = {};
    let imageData = {};
    let cache = [];
    let current = -1;
    
    function loadDOMElems() {
        const prethodni = document.getElementById('prethodni');
        const sljedeci = document.getElementById('sljedeci');
        const galerija = document.getElementById('galerija-container');

        elems = {
            prethodni, sljedeci, galerija
        }
    }

    function initEventListeners() {
        elems.prethodni.addEventListener('click', e => {
            if(current > 0) {
                current -= 1;
                updateButtonAvailability();
                loadCurrentImagesFromCache();
            }
        });

        elems.sljedeci.addEventListener('click', e => {
            if(current == cache.length - 1) {
                Pozivi.getImageData(imageData, data => {
                    imageData = data;
                    loadNewImages();
                    updateButtonAvailability();
                },
                err => {
                    console.log(err);
                });
            } else {
                current += 1;
                updateButtonAvailability();
                loadCurrentImagesFromCache();
            }
        });
    }

    function loadNewImages() {
        if(imageData.toLoad.length) {
            let images = imageData.toLoad.map(name => `<img src="/images/${name}" alt="${name}"/>`).join('');
            elems.galerija.innerHTML = `<div class="galerija">${images}</div>`;
            cache.push(elems.galerija.firstChild);
            current += 1;
        }
    }

    function loadCurrentImagesFromCache() {
        elems.galerija.removeChild(elems.galerija.firstChild);
        elems.galerija.appendChild(cache[current]);
    }

    function updateButtonAvailability() {
        elems.prethodni.disabled = current == 0;
        const rest = imageData.images.filter(image => !image.loaded).length;
        elems.sljedeci.disabled = current == cache.length - 1 && rest == 0;
    }

    function main() {
        loadDOMElems();
        initEventListeners();
        Pozivi.getImageData(null, data => {
            imageData = data;
            loadNewImages();
            updateButtonAvailability();
        }, err => {
            console.log(err);
        });
    }

    return main;
}();

Pocetna();
