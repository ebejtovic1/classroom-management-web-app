const fs = require('fs');
const path = require('path');

function filterImagesToLoad(imageData) {
    const threeUnloaded = imageData.images.filter(image => !image.loaded).filter((_, index) => index < 3);
    threeUnloaded.forEach(image => image.loaded = true);
    imageData.toLoad = threeUnloaded.map(image => image.path);
}

function loadImageData(imageData, callback) {
    if(imageData) {
        filterImagesToLoad(imageData);
        callback(imageData);
        return;
    }

    const directory = path.join(__dirname, '/public/images');
    fs.readdir(directory, (err, files) => {     
        imageData = {
            images: [],
            toLoad: []
        };

        if(!err) {
            imageData.images = files.map(path => ({ path, loaded: false }));
        }
        
        filterImagesToLoad(imageData);
        callback(imageData);
    });
}

module.exports = loadImageData;
